# MonitorX

**Real-time Minecraft server monitor with a live Discord dashboard.**

MonitorX keeps **one single Discord message** and edits it in place every few seconds with your server's live stats: TPS, MSPT, RAM, CPU, disk, players, chunks and entities. No bot, no token, no channel spam. Just a webhook URL.

Made by **HozvikCloud** (proprietary, all rights reserved) · Developer: **˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)**

---

## Features

- Built with Discord **Components V2** (containers, text, separators) instead of classic embeds
- One live Discord message, edited in place (never spams new messages)
- Only a **Discord webhook URL** is needed (no bot token, no IDs)
- Live **TPS** and **MSPT** (real tick time on Paper; clearly marked estimate on Spigot)
- **RAM**, **JVM heap**, **CPU**, **disk** usage with progress bars
- Online players count, loaded chunks and entities (total and per world)
- Server **uptime** and ONLINE / OFFLINE status (the embed turns red when the server stops)
- Every section can be switched on or off, custom embed colour and optional emojis
- **Admin log webhook** (second, separate channel): server online / offline / crash with exact times and uptime, player join / leave / kick with the online player list, admin and console commands, low TPS / high RAM alerts
- Live dashboard shows "Online since", a counting "Last updated X ago", optional player names and a custom server name
- Auto-recovers if the dashboard message is deleted; backs off automatically when Discord rate-limits
- Works on **Java 8 and newer**, no extra libraries needed

## Compatibility

| | |
|---|---|
| Server software | Spigot, Paper, Purpur and other Bukkit-based servers |
| Minecraft versions | 1.8 and newer (designed for 1.8 up to the latest release) |
| Java | 8 or newer |
| Not supported | Folia, Fabric, Forge, NeoForge, BungeeCord, Velocity, Bedrock |

> Servers on Java 8 should use a recent Java 8 update (8u261 or newer) so that Discord's HTTPS certificate is trusted.

## Installation

1. Download `MonitorX-<version>.jar` and put it in your server's `plugins/` folder.
2. Start the server once. `plugins/MonitorX/config.yml` is created.
3. In Discord: **Channel settings → Integrations → Webhooks → New Webhook → Copy Webhook URL**.
4. Paste the URL into `config.yml` under `discord.webhook-url`.
5. Run `/monitorx reload` (or restart). The dashboard message appears in your channel.

## Configuration

`plugins/MonitorX/config.yml`

| Key | Default | Description |
|---|---|---|
| `discord.webhook-url` | *(empty)* | Your Discord webhook URL |
| `discord.webhook-name` | `MonitorX` | Custom name shown on the dashboard message (empty = webhook's own name) |
| `discord.webhook-avatar-url` | *(empty)* | Direct image URL for a custom avatar (empty = webhook's own avatar) |
| `monitor.refresh-interval-seconds` | `5` | How often the message is edited (minimum 1) |
| `monitor.embed-color` | `#2B2D31` | Accent bar colour of the dashboard container (hex, empty = none) |
| `monitor.progress-bar-length` | `12` | Length of the bars (5 to 20) |
| `monitor.show-resources` | `true` | RAM / CPU / Storage / JVM Heap |
| `monitor.show-configuration` | `true` | Software / Bukkit / TPS / MSPT |
| `monitor.show-live-stats` | `true` | CPU / Memory / Disk bars |
| `monitor.show-actions` | `true` | Players online |
| `monitor.show-world-details` | `true` | Chunks and entities |
| `monitor.server-name` | *(auto)* | Name in the embed title (empty = ip:port) |
| `monitor.show-timestamps` | `true` | "Online since" and "Last updated" lines |
| `monitor.footer-text` | *(empty)* | Small footer text |
| `monitor.show-player-names` | `false` | List online player names with ping |
| `monitor.emojis` | `{}` | Optional emoji overrides (unicode or Discord custom emoji) |

> Name and avatar are applied when the message is posted. After changing them, run `/monitorx reset` to post a fresh message with the new look.

Discord allows about 5 edits per 5 seconds per webhook, so the default of 5 seconds is safe. If you see rate-limit warnings in the console, raise the interval.

> **One dashboard message only:** the id of the live message is stored in `plugins/MonitorX/dashboard.yml` (not in `config.yml`), so the same message is edited forever, even if you replace `config.yml`. If a fresh message is needed (`/monitorx reset`, an upgrade from 1.2.x, or Discord keeps refusing edits), the new one is posted and the **old one is deleted automatically**.
>
> **Upgrading from 1.2.x:** the old embed message cannot be edited into the new Components V2 layout, so it is replaced once. Components V2 messages have no `content`/embeds; role pings are sent as text inside the message.

## Admin log (second webhook)

Set `admin-log.enabled: true` and put a webhook of your **admin channel** in `admin-log.webhook-url`. Every event is posted as a new message (batched and rate-limit safe). Run `/monitorx test` to check it.

| Event | What is shown |
|---|---|
| Server online | Online-since time, software, Java, plugins, and the previous session (when it started/stopped, how long it ran, how long the server was offline) |
| Server offline | Went-offline time, online-since, total uptime, peak players, join count |
| After a crash | Detected when the last session never shut down cleanly; shows last-seen-alive time and downtime, can ping a role |
| Player join / leave | Online count, gamemode, ping, world, rank, UUID, session length, online player list, optional IP, skin head |
| Player kick | Reason |
| Admin commands | Who, command, world and coordinates. High-risk commands (op, ban, stop, ...) are red. Passwords commands (`/login`, `/register`, ...) are never logged |
| Console / RCON commands | Command and sender |
| Gamemode changes | By admins |
| Alerts | Low TPS / high RAM, repeated after a cooldown, plus a recovery message |

Admins are OPs and players with `monitorx.admin` (or `admin-log.commands.admin-permission`). All options are documented in `config.yml`.

Times are shown in `admin-log.time-zone` (default `Asia/Kolkata`) together with Discord's live "x minutes ago".

## Commands

Main command: `/monitorx` (aliases: `/mx`, `/xmon`)

| Command | Description |
|---|---|
| `/monitorx status` | Show TPS, MSPT, heap, disk, uptime and webhook state in-game |
| `/monitorx reload` | Reload `config.yml` |
| `/monitorx forceupdate` | Push an update to Discord right now |
| `/monitorx reset` | Post a fresh dashboard message and delete the old one |
| `/monitorx test` | Send a test message to the admin log channel |
| `/monitorx help` | Show the command list |

## Permissions

| Permission | Default | Description |
|---|---|---|
| `monitorx.admin` | op | Use all `/monitorx` commands |

## About TPS and MSPT

- **Paper / Purpur:** MSPT is the real tick processing time reported by the server.
- **Spigot:** the server does not expose tick processing time, so MonitorX shows an estimate. A healthy server shows `<50 ms (est.)`; an overloaded one shows a `~value (est.)`.
- **Uptime** is the uptime of the server process, so it is not reset by `/monitorx reload`.

## Troubleshooting

| Problem | Fix |
|---|---|
| `Webhook not configured` | Set `discord.webhook-url` in `config.yml`, then `/monitorx reload` |
| `Dashboard message ... was deleted` | You deleted it in Discord; a new one is posted automatically |
| `Webhook rejected (401/403)` | The webhook was deleted or the URL is wrong. Create a new one |
| `Rate limited` | Increase `monitor.refresh-interval-seconds` |
| Nothing is posted on Java 8 | Update Java 8 to a recent build (8u261+) |

## Building from source

Requirements: JDK 8 or newer and Maven.

```bash
mvn clean package
```

The plugin jar is created at `target/MonitorX-<version>.jar`.

## License

**HozvikCloud Proprietary License - Use Only. All Rights Reserved.** See [LICENSE](LICENSE).

- You may **use** MonitorX on servers you own/administer and change the settings offered in `config.yml`.
- You may **not** modify, rebrand, remove credits, decompile, leak, share, resell, open-source or customise it (including with AI tools).
- All rights and credits belong to **HozvikCloud**. Any breach can lead to licence termination, service termination, copyright strikes/takedowns and legal action.

Copyright (c) 2026 HozvikCloud · ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil). All Rights Reserved.
