/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx;

import com.hozvikcloud.monitorx.admin.AdminEvents;
import com.hozvikcloud.monitorx.admin.AdminListener;
import com.hozvikcloud.monitorx.admin.AdminLogger;
import com.hozvikcloud.monitorx.admin.AlertMonitor;
import com.hozvikcloud.monitorx.config.PluginConfig;
import com.hozvikcloud.monitorx.data.StateStore;
import com.hozvikcloud.monitorx.discord.DiscordClient;
import com.hozvikcloud.monitorx.metrics.MemoryMetrics;
import com.hozvikcloud.monitorx.metrics.ServerMetricsCollector;
import com.hozvikcloud.monitorx.metrics.TpsTracker;
import com.hozvikcloud.monitorx.task.MonitorUpdateTask;
import com.hozvikcloud.monitorx.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MonitorXPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {

    private PluginConfig cfg;
    private TpsTracker tps;
    private ServerMetricsCollector collector;
    private DiscordClient discord;
    private MonitorUpdateTask task;

    private StateStore state;
    private AdminLogger adminLogger;
    private AdminEvents adminEvents;
    private AlertMonitor alerts;
    private BukkitTask heartbeat;
    private final long sessionStartMs = TimeUtil.jvmStartMs();

    @Override
    public void onEnable() {
        if (task != null) {
            task.stop();
            task = null;
        }
        cfg = new PluginConfig(this);
        cfg.load();

        tps = new TpsTracker(this);
        tps.start();
        collector = new ServerMetricsCollector(this, tps);

        discord = new DiscordClient(getLogger(), getDescription().getVersion());
        task = new MonitorUpdateTask(this, cfg, discord, collector);
        task.start();

        // ---- admin webhook (server status, players, admin activity, alerts) ----
        state = new StateStore(this);
        final StateStore.Previous previous = state.begin(sessionStartMs);
        adminLogger = new AdminLogger(this, cfg, discord);
        adminLogger.start();
        adminEvents = new AdminEvents(this, cfg, adminLogger, sessionStartMs);
        getServer().getPluginManager().registerEvents(new AdminListener(adminEvents), this);
        alerts = new AlertMonitor(this, cfg, tps, adminEvents);
        alerts.start();
        heartbeat = Bukkit.getScheduler().runTaskTimerAsynchronously(this, new Runnable() {
            @Override public void run() { if (state != null) state.heartbeat(); }
        }, 600L, 600L);
        // Next tick = the server has finished loading, so this is the real "online" moment.
        // A /reload of the plugin is not announced as a restart.
        if (previous.kind != StateStore.PreviousKind.RELOAD) {
            Bukkit.getScheduler().runTask(this, new Runnable() {
                @Override public void run() { if (adminEvents != null) adminEvents.serverOnline(previous); }
            });
        }

        if (getCommand("monitorx") != null) {
            getCommand("monitorx").setExecutor(this);
            getCommand("monitorx").setTabCompleter(this);
        }

        if (cfg.isConfigured()) {
            getLogger().info("MonitorX enabled. Webhook live, refresh every " + cfg.getRefreshIntervalSeconds() + "s.");
        } else {
            getLogger().warning("MonitorX loaded but webhook is not configured. Set discord.webhook-url in config.yml.");
        }
        if (cfg.isAdminEnabled()) {
            getLogger().info("Admin log webhook active.");
        } else if (cfg.isAdminSwitchedOn()) {
            getLogger().warning("admin-log.enabled is true but admin-log.webhook-url is missing or invalid.");
        }
    }

    @Override
    public void onDisable() {
        boolean realShutdown = isRealShutdown();
        if (heartbeat != null) { heartbeat.cancel(); heartbeat = null; }
        if (alerts != null) { alerts.stop(); alerts = null; }
        if (adminLogger != null) {
            adminLogger.stop();
            if (realShutdown && adminEvents != null) {
                adminEvents.serverOffline();
                adminLogger.flushBlocking(8); // scheduler is gone during disable, send directly
            }
            adminLogger = null;
        }
        if (state != null) {
            if (realShutdown) state.markStopped();
            state = null;
        }
        adminEvents = null;
        if (task != null) {
            if (realShutdown) task.sendShutdownStatus();
            task.stop();
            task = null;
        }
        if (discord != null) { discord.close(); discord = null; }
        if (tps != null) { tps.stop(); tps = null; }
    }

    /** False when only this plugin is being reloaded/disabled while the server keeps running. */
    private boolean isRealShutdown() {
        try {
            Object stopping = Bukkit.class.getMethod("isStopping").invoke(null);
            if (stopping instanceof Boolean) return (Boolean) stopping;
        } catch (Throwable ignored) {
            // Spigot has no isStopping(): assume a normal shutdown
        }
        return true;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("monitorx.admin")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender, label);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload":
                cfg.load();
                if (task != null) task.stop();
                task = new MonitorUpdateTask(this, cfg, discord, collector);
                task.start();
                if (alerts != null) alerts.start();
                sender.sendMessage(ChatColor.GREEN + "Config reloaded.");
                break;
            case "test":
                if (!cfg.isAdminEnabled()) {
                    sender.sendMessage(ChatColor.RED + "Admin log is off or its webhook is not set (admin-log.* in config.yml).");
                } else {
                    adminEvents.test(sender.getName());
                    sender.sendMessage(ChatColor.GREEN + "Test message queued for the admin channel.");
                }
                break;
            case "status": sendStatus(sender); break;
            case "forceupdate":
                if (!cfg.isConfigured()) {
                    sender.sendMessage(ChatColor.RED + "Webhook not configured.");
                } else {
                    task.forceUpdate();
                    sender.sendMessage(ChatColor.GREEN + "Forced a refresh.");
                }
                break;
            case "reset":
                cfg.setMessageId("");
                if (task != null) task.forceUpdate();
                sender.sendMessage(ChatColor.GREEN + "Saved message id cleared - next cycle will post a fresh message.");
                break;
            default: sendHelp(sender, label);
        }
        return true;
    }

    private void sendHelp(CommandSender s, String label) {
        s.sendMessage(ChatColor.GOLD + "MonitorX");
        s.sendMessage(ChatColor.YELLOW + "/" + label + " status " + ChatColor.GRAY + "- show local metrics");
        s.sendMessage(ChatColor.YELLOW + "/" + label + " reload " + ChatColor.GRAY + "- reload config");
        s.sendMessage(ChatColor.YELLOW + "/" + label + " forceupdate " + ChatColor.GRAY + "- push to Discord now");
        s.sendMessage(ChatColor.YELLOW + "/" + label + " reset " + ChatColor.GRAY + "- clear message id and repost");
        s.sendMessage(ChatColor.YELLOW + "/" + label + " test " + ChatColor.GRAY + "- send a test to the admin log channel");
        s.sendMessage(ChatColor.YELLOW + "/" + label + " help");
    }

    private static String ago(long epochMs) {
        if (epochMs <= 0) return ChatColor.YELLOW + "never";
        return ChatColor.GREEN + TimeUtil.duration(System.currentTimeMillis() - epochMs) + " ago";
    }

    private void sendStatus(CommandSender s) {
        ServerMetricsCollector.Snapshot snap = collector.collectSnapshot(true);
        double[] tpsArr = snap.getTps();
        MemoryMetrics mem = snap.getMemory();

        s.sendMessage(ChatColor.GOLD + "MonitorX Status");
        s.sendMessage(ChatColor.AQUA + "TPS: " + ChatColor.WHITE
                + String.format("%.2f, %.2f, %.2f", tpsArr[0], tpsArr[1], tpsArr[2])
                + ChatColor.DARK_AQUA + "  MSPT: " + ChatColor.WHITE
                + snap.getMsptDisplay());
        s.sendMessage(ChatColor.AQUA + "Heap: " + ChatColor.WHITE
                + MemoryMetrics.formatBytes(mem.getHeapUsedBytes()) + " / "
                + MemoryMetrics.formatBytes(mem.getHeapMaxBytes())
                + String.format(" (%.1f%%)", mem.getHeapUsagePercentage()));
        s.sendMessage(ChatColor.AQUA + "Disk: " + ChatColor.WHITE
                + MemoryMetrics.formatBytes(snap.getDisk().getUsedSpaceBytes()) + " / "
                + MemoryMetrics.formatBytes(snap.getDisk().getTotalSpaceBytes())
                + String.format(" (%.1f%%)", snap.getDisk().getUsedPercentage()));
        s.sendMessage(ChatColor.AQUA + "Uptime: " + ChatColor.WHITE + snap.getUptime());
        s.sendMessage(ChatColor.AQUA + "Webhook: "
                + (cfg.isConfigured()
                    ? ChatColor.GREEN + "ok (" + cfg.getRefreshIntervalSeconds() + "s refresh)"
                    : ChatColor.RED + "not configured"));
        s.sendMessage(ChatColor.AQUA + "Last dashboard update: " + ago(task == null ? 0 : task.getLastSuccessMs()));
        s.sendMessage(ChatColor.AQUA + "Admin log: "
                + (cfg.isAdminEnabled()
                    ? ChatColor.GREEN + "on" + ChatColor.GRAY + " (last sent " + ago(adminLogger == null ? 0 : adminLogger.getLastSuccessMs())
                        + ChatColor.GRAY + (adminLogger != null && adminLogger.getQueueSize() > 0 ? ", " + adminLogger.getQueueSize() + " queued" : "") + ")"
                    : (cfg.isAdminSwitchedOn() ? ChatColor.RED + "webhook missing" : ChatColor.GRAY + "off")));
        s.sendMessage(ChatColor.AQUA + "Message id: "
                + (cfg.getMessageId() == null || cfg.getMessageId().isEmpty()
                    ? ChatColor.YELLOW + "(none, will post on next cycle)"
                    : ChatColor.GREEN + cfg.getMessageId()));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length != 1) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (String opt : Arrays.asList("status", "reload", "forceupdate", "reset", "test", "help")) {
            if (opt.startsWith(args[0].toLowerCase())) out.add(opt);
        }
        return out;
    }
}
