/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.admin;

import com.hozvikcloud.monitorx.config.PluginConfig;
import com.hozvikcloud.monitorx.data.StateStore;
import com.hozvikcloud.monitorx.discord.v2.ContainerBuilder;
import com.hozvikcloud.monitorx.metrics.NetworkAndPlayerMetrics;
import com.hozvikcloud.monitorx.util.ServerNames;
import com.hozvikcloud.monitorx.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.URLEncoder;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Builds every admin-channel embed and hands it to the AdminLogger. Main thread only. */
public class AdminEvents {

    private static final int GREEN = 0x2ECC71;
    private static final int RED = 0xE74C3C;
    private static final int ORANGE = 0xE67E22;
    private static final int BLUE = 0x3498DB;
    private static final int YELLOW = 0xF1C40F;
    private static final int PURPLE = 0x9B59B6;
    private static final int GREY = 0x95A5A6;

    private static final String DOT = "`\u30FB\u273F`";

    private final JavaPlugin plugin;
    private final PluginConfig cfg;
    private final AdminLogger out;
    private final long sessionStartMs;

    private final Map<UUID, Long> joinTimes = new ConcurrentHashMap<>();
    private int peakPlayers = 0;
    private int totalJoins = 0;

    public AdminEvents(JavaPlugin plugin, PluginConfig cfg, AdminLogger out, long sessionStartMs) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.out = out;
        this.sessionStartMs = sessionStartMs;
    }

    // ---------------------------------------------------------------- server

    public void serverOnline(StateStore.Previous prev) {
        if (!cfg.isEvServerStatus()) return;
        ZoneId z = cfg.getTimeZone();
        long now = System.currentTimeMillis();
        boolean crashed = prev.kind == StateStore.PreviousKind.CRASH;

        ContainerBuilder c = card(crashed ? ORANGE : GREEN,
                crashed ? "\uD83D\uDFE0 Server Back Online (after crash)" : "\uD83D\uDFE2 Server Online");
        c.text("-# **" + server() + "** is now online.");
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "Online since", TimeUtil.stamp(sessionStartMs, z));
        ln(f, "Software", code(Bukkit.getName() + " " + shortVersion()));
        ln(f, "Minecraft", code(Bukkit.getBukkitVersion()));
        ln(f, "Java", code(System.getProperty("java.version", "?")));
        ln(f, "Max players", code(String.valueOf(Bukkit.getMaxPlayers())));
        ln(f, "Plugins", code(String.valueOf(Bukkit.getPluginManager().getPlugins().length)));
        c.text(f.toString());

        StringBuilder p = new StringBuilder();
        switch (prev.kind) {
            case NONE:
                ln(p, "Previous session", "First start recorded by MonitorX.");
                break;
            case CLEAN:
                ln(p, "Previous session", "");
                ln(p, "Started", TimeUtil.stamp(prev.startedAt, z));
                ln(p, "Stopped", TimeUtil.stamp(prev.endedAt, z));
                ln(p, "Ran for", code(TimeUtil.duration(prev.endedAt - prev.startedAt)));
                ln(p, "Was offline for", code(TimeUtil.duration(sessionStartMs - prev.endedAt)));
                break;
            case CRASH:
                ln(p, "Previous session ended unexpectedly", "");
                p.append("-# The server did not shut down cleanly (crash, kill or power loss).\n");
                ln(p, "Started", TimeUtil.stamp(prev.startedAt, z));
                ln(p, "Last seen alive", TimeUtil.stamp(prev.endedAt, z));
                ln(p, "Ran for about", code(TimeUtil.duration(prev.endedAt - prev.startedAt)));
                ln(p, "Was down for about", code(TimeUtil.duration(now - prev.endedAt)));
                break;
            default:
                break;
        }
        if (p.length() > 0) {
            c.separator();
            c.text(p.toString());
        }
        finish(c, crashed && cfg.isMentionOnCrash());
    }

    public void serverOffline() {
        if (!cfg.isEvServerStatus()) return;
        ZoneId z = cfg.getTimeZone();
        long now = System.currentTimeMillis();
        ContainerBuilder c = card(RED, "\uD83D\uDD34 Server Offline");
        c.text("-# **" + server() + "** went offline.");
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "Went offline", TimeUtil.stamp(now, z));
        ln(f, "Was online since", TimeUtil.stamp(sessionStartMs, z));
        ln(f, "Total uptime", code(TimeUtil.duration(now - sessionStartMs)));
        ln(f, "Peak players", code(String.valueOf(peakPlayers)));
        ln(f, "Player joins", code(String.valueOf(totalJoins)));
        c.text(f.toString());
        finish(c, cfg.isMentionOnStop());
    }

    // --------------------------------------------------------------- players

    public void playerJoin(Player p) {
        joinTimes.put(p.getUniqueId(), System.currentTimeMillis());
        totalJoins++;
        int online = Bukkit.getOnlinePlayers().size();
        if (online > peakPlayers) peakPlayers = online;
        if (!cfg.isEvPlayerJoin()) return;

        boolean first = !p.hasPlayedBefore();
        ContainerBuilder c = card(GREEN, "\u2795 Player Joined");
        head(c, "-# **" + md(p.getName()) + "** joined the server."
                + (first ? "\n-# \uD83C\uDD95 First time on this server!" : ""), p);
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "Online", code(online + " / " + Bukkit.getMaxPlayers()));
        ln(f, "Gamemode", code(gm(p.getGameMode())));
        ln(f, "Ping", code(NetworkAndPlayerMetrics.extractPing(p) + " ms"));
        ln(f, "World", code(p.getWorld().getName()));
        ln(f, "Rank", code(isAdmin(p) ? (p.isOp() ? "Admin (OP)" : "Admin") : "Player"));
        if (!first && p.getFirstPlayed() > 0) ln(f, "First joined", TimeUtil.rel(p.getFirstPlayed()));
        ln(f, "UUID", code(p.getUniqueId().toString()));
        if (cfg.isShowIp()) ln(f, "IP", code(ip(p)));
        c.text(f.toString());
        if (cfg.isEvPlayerList()) {
            c.separator();
            c.text(playerListLine(Bukkit.getOnlinePlayers(), null));
        }
        finish(c, false);
    }

    public void playerQuit(Player p) {
        Long joined = joinTimes.remove(p.getUniqueId());
        if (!cfg.isEvPlayerQuit()) return;

        int online = Math.max(0, Bukkit.getOnlinePlayers().size() - 1);
        ContainerBuilder c = card(GREY, "\u2796 Player Left");
        head(c, "-# **" + md(p.getName()) + "** left the server.", p);
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "Online", code(online + " / " + Bukkit.getMaxPlayers()));
        if (joined != null) ln(f, "Session", code(TimeUtil.duration(System.currentTimeMillis() - joined)));
        ln(f, "World", code(p.getWorld().getName()));
        c.text(f.toString());
        if (cfg.isEvPlayerList()) {
            c.separator();
            c.text(playerListLine(Bukkit.getOnlinePlayers(), p.getUniqueId()));
        }
        finish(c, false);
    }

    public void playerKick(Player p, String reason) {
        if (!cfg.isEvPlayerKick()) return;
        ContainerBuilder c = card(RED, "\u26D4 Player Kicked");
        head(c, "-# **" + md(p.getName()) + "** was removed from the server.", p);
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "World", code(p.getWorld().getName()));
        c.text(f.toString());
        c.text(block(reason == null || reason.isEmpty() ? "(none)" : reason));
        finish(c, false);
    }

    public void gamemodeChange(Player p, GameMode now) {
        if (!cfg.isEvGamemode() || !isAdmin(p)) return;
        ContainerBuilder c = card(PURPLE, "\uD83C\uDFAE Gamemode Changed");
        head(c, "-# **" + md(p.getName()) + "** (admin) changed gamemode.", p);
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "Change", code(gm(p.getGameMode()) + " \u2192 " + gm(now)));
        ln(f, "World", code(p.getWorld().getName()));
        c.text(f.toString());
        finish(c, false);
    }

    // -------------------------------------------------------------- commands

    public void playerCommand(Player p, String raw) {
        String base = baseCommand(raw);
        if (base.isEmpty() || isSecret(base) || cfg.isCommandIgnored(base)) return;
        boolean admin = isAdmin(p);
        if (!admin && !cfg.isLogAllPlayerCommands()) return;
        if (admin && !cfg.isEvAdminCommands()) return;

        boolean hot = cfg.isCommandHighlighted(base);
        ContainerBuilder c = card(hot ? RED : YELLOW, hot ? "\u26A0\uFE0F High-Risk Command" : "\uD83D\uDEE1\uFE0F Admin Command");
        head(c, "-# **" + md(p.getName()) + "**" + (admin ? " (admin)" : "") + " ran a command.", p);
        c.separator();
        c.text(block(raw));
        Location l = p.getLocation();
        StringBuilder f = new StringBuilder();
        ln(f, "Where", code(p.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ()));
        ln(f, "Gamemode", code(gm(p.getGameMode())));
        c.text(f.toString());
        finish(c, false);
    }

    public void consoleCommand(String sender, String raw) {
        if (!cfg.isEvConsoleCommands()) return;
        String base = baseCommand(raw);
        if (base.isEmpty() || isSecret(base) || cfg.isCommandIgnored(base)) return;
        boolean hot = cfg.isCommandHighlighted(base);
        ContainerBuilder c = card(hot ? RED : BLUE, hot ? "\u26A0\uFE0F High-Risk Console Command" : "\uD83D\uDDA5\uFE0F Console Command");
        c.text("-# Command run by **" + md(sender) + "**.");
        c.separator();
        c.text(block(raw));
        finish(c, false);
    }

    // ---------------------------------------------------------------- alerts

    public void alert(String title, String detail, boolean recovered) {
        ContainerBuilder c = card(recovered ? GREEN : ORANGE, (recovered ? "\u2705 " : "\u26A0\uFE0F ") + title);
        c.text("-# " + detail);
        finish(c, !recovered && cfg.isMentionOnAlert());
    }

    public void test(String by) {
        ContainerBuilder c = card(BLUE, "\u2705 MonitorX admin log works");
        c.text("-# Test message requested by **" + md(by) + "**. Events will appear in this channel.");
        c.separator();
        StringBuilder f = new StringBuilder();
        ln(f, "Online players", code(String.valueOf(Bukkit.getOnlinePlayers().size())));
        ln(f, "Server online since", TimeUtil.stamp(sessionStartMs, cfg.getTimeZone()));
        c.text(f.toString());
        finish(c, false);
    }

    // --------------------------------------------------------------- helpers

    public int getPeakPlayers() { return peakPlayers; }

    public boolean isAdmin(Player p) {
        if (p.isOp() || p.hasPermission("monitorx.admin")) return true;
        String perm = cfg.getAdminPermission();
        return perm != null && !perm.isEmpty() && p.hasPermission(perm);
    }

    /** Container with accent colour and a bold title, followed by a separator. */
    private ContainerBuilder card(int color, String title) {
        return new ContainerBuilder().accent(color).text("**" + title + "**").separator();
    }

    /** Adds the time + server footer and queues the card. */
    private void finish(ContainerBuilder c, boolean mention) {
        c.separator();
        c.text("-# " + DOT + " **Time :** " + TimeUtil.stamp(System.currentTimeMillis(), cfg.getTimeZone())
                + "  \u30FB  " + server());
        out.submit(c, mention);
    }

    /** "-# `・✿` **label :** value" line. */
    private static void ln(StringBuilder sb, String label, String value) {
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) != '\n') sb.append('\n');
        sb.append("-# ").append(DOT).append(" **").append(label).append(" :** ").append(value).append('\n');
    }

    private String server() {
        return ServerNames.resolve(plugin, cfg);
    }

    /** Description text, with the player's skin head on the right when enabled. */
    private void head(ContainerBuilder c, String text, Player p) {
        String url = null;
        if (cfg.isPlayerHeads()) {
            try {
                url = "https://mc-heads.net/avatar/" + URLEncoder.encode(p.getName(), "UTF-8") + "/64";
            } catch (UnsupportedEncodingException ignored) {
            }
        }
        c.section(text, url);
    }

    private String playerListLine(Collection<? extends Player> online, UUID exclude) {
        List<String> names = new ArrayList<>();
        for (Player pl : online) {
            if (exclude != null && exclude.equals(pl.getUniqueId())) continue;
            names.add(pl.getName());
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        String title = "Online players (" + names.size() + ")";
        if (names.isEmpty()) return "-# " + DOT + " **" + title + " :** _nobody_";
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (String n : names) {
            String piece = (shown == 0 ? "" : ", ") + "`" + n.replace("`", "'") + "`";
            if (shown >= cfg.getMaxListedPlayers() || sb.length() + piece.length() > 900) break;
            sb.append(piece);
            shown++;
        }
        if (shown < names.size()) sb.append(" +").append(names.size() - shown).append(" more");
        return "-# " + DOT + " **" + title + " :** " + sb;
    }

    private String ip(Player p) {
        try {
            InetSocketAddress a = p.getAddress();
            return a == null || a.getAddress() == null ? "unknown" : a.getAddress().getHostAddress();
        } catch (Throwable t) {
            return "unknown";
        }
    }

    private static String shortVersion() {
        String v = Bukkit.getVersion();
        return v.length() > 60 ? v.substring(0, 60) : v;
    }

    private static String gm(GameMode m) {
        return m == null ? "?" : m.name().charAt(0) + m.name().substring(1).toLowerCase();
    }

    static String baseCommand(String raw) {
        if (raw == null) return "";
        String c = raw.trim();
        if (c.startsWith("/")) c = c.substring(1);
        int sp = c.indexOf(' ');
        if (sp >= 0) c = c.substring(0, sp);
        int colon = c.indexOf(':'); // minecraft:op -> op
        if (colon >= 0) c = c.substring(colon + 1);
        return c.toLowerCase(java.util.Locale.ROOT);
    }

    /** Commands that carry passwords are never logged, whatever the config says. */
    private static boolean isSecret(String base) {
        switch (base) {
            case "login": case "l": case "log": case "register": case "reg":
            case "changepassword": case "cp": case "unregister": case "passwd":
            case "password": case "authme": case "2fa": case "totp":
                return true;
            default:
                return false;
        }
    }

    private static String code(String s) {
        String v = s == null || s.isEmpty() ? "-" : s;
        if (v.length() > 900) v = v.substring(0, 900) + "...";
        return "`" + v.replace("`", "'") + "`";
    }

    private static String block(String s) {
        String v = s == null ? "" : s.replace("```", "'''");
        if (v.length() > 900) v = v.substring(0, 900) + "...";
        return "```\n" + v + "\n```";
    }

    /** Escapes Discord markdown in names. */
    private static String md(String s) {
        if (s == null) return "?";
        return s.replace("\\", "\\\\").replace("*", "\\*").replace("_", "\\_")
                .replace("~", "\\~").replace("`", "'").replace("|", "\\|").replace(">", "\\>");
    }
}
