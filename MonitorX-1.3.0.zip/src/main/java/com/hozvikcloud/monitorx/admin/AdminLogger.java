/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.admin;

import com.hozvikcloud.monitorx.config.PluginConfig;
import com.hozvikcloud.monitorx.discord.DiscordClient;
import com.hozvikcloud.monitorx.discord.JsonObjectBuilder;
import com.hozvikcloud.monitorx.discord.v2.ContainerBuilder;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Queue + sender for the admin webhook. Events are queued from any thread, then an
 * async task sends them in batches (up to 10 embeds per message) every 2 seconds, so
 * a burst of joins can never trip Discord's rate limit. 429s are retried after the
 * time Discord asks for.
 */
public class AdminLogger implements Runnable {

    private static final int MAX_QUEUE = 300;
    // Discord limits a Components V2 message to 40 components and 4000 characters of text.
    private static final int MAX_CARDS_PER_MESSAGE = 8;
    private static final int MAX_BATCH_TEXT = 3400;
    private static final int MAX_BATCH_COMPONENTS = 36;

    private static final class Entry {
        final String json;          // one container
        final String mentionRoleId; // "" = no ping
        final int textChars;
        final int components;
        Entry(String json, String mentionRoleId, int textChars, int components) {
            this.json = json;
            this.mentionRoleId = mentionRoleId == null ? "" : mentionRoleId;
            this.textChars = textChars;
            this.components = components;
        }
    }

    private final JavaPlugin plugin;
    private final PluginConfig cfg;
    private final DiscordClient discord;
    private final Deque<Entry> queue = new ArrayDeque<>();
    private BukkitTask task;
    private long notBeforeMs = 0;
    private int dropped = 0;
    private int consecutiveFailures = 0;
    private volatile long lastSuccessMs = 0;

    public AdminLogger(JavaPlugin plugin, PluginConfig cfg, DiscordClient discord) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.discord = discord;
    }

    public synchronized void start() {
        stop();
        task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this, 40L, 40L);
    }

    public synchronized void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    public long getLastSuccessMs() { return lastSuccessMs; }

    public synchronized int getQueueSize() { return queue.size(); }

    public boolean isActive() {
        return cfg.isAdminEnabled();
    }

    /** Queue a card. mentionRole = true pings the configured role (if any). */
    public void submit(ContainerBuilder card, boolean mentionRole) {
        if (!cfg.isAdminEnabled() || card == null) return;
        String role = mentionRole ? cfg.getMentionRoleId() : "";
        String json = card.build().build();
        synchronized (this) {
            if (queue.size() >= MAX_QUEUE) {
                queue.pollFirst();
                dropped++;
            }
            queue.addLast(new Entry(json, role, card.getTextChars(), card.getComponentCount()));
        }
    }

    @Override
    public void run() {
        flushOnce(false);
    }

    /** Sends everything still queued, on the calling thread (used on shutdown). */
    public void flushBlocking(int maxBatches) {
        if (!cfg.isAdminEnabled()) return;
        for (int i = 0; i < maxBatches; i++) {
            if (!flushOnce(true)) break;
        }
    }

    /** @return true when a batch was sent and more may remain. */
    private boolean flushOnce(boolean ignoreBackoff) {
        if (!cfg.isAdminEnabled()) {
            synchronized (this) { queue.clear(); }
            return false;
        }
        if (!ignoreBackoff && System.currentTimeMillis() < notBeforeMs) return false;

        List<Entry> batch = new ArrayList<>();
        int chars = 0;
        int comps = 0;
        synchronized (this) {
            while (!queue.isEmpty() && batch.size() < MAX_CARDS_PER_MESSAGE) {
                Entry e = queue.peekFirst();
                if (!batch.isEmpty() && (chars + e.textChars > MAX_BATCH_TEXT
                        || comps + e.components > MAX_BATCH_COMPONENTS)) break;
                batch.add(queue.pollFirst());
                chars += e.textChars;
                comps += e.components;
            }
        }
        if (batch.isEmpty()) return false;

        Set<String> roles = new LinkedHashSet<>();
        List<Object> top = new ArrayList<>();
        for (Entry e : batch) {
            if (!e.mentionRoleId.isEmpty()) roles.add(e.mentionRoleId);
        }
        if (!roles.isEmpty()) {
            StringBuilder ping = new StringBuilder();
            for (String r : roles) ping.append("<@&").append(r).append("> ");
            top.add(ContainerBuilder.topLevelText(ping.toString().trim()));
        }
        for (Entry e : batch) top.add(new JsonObjectBuilder.Raw(e.json));

        JsonObjectBuilder payload = new JsonObjectBuilder();
        cfg.getAdminTarget().applyIdentity(payload);
        payload.add("flags", ContainerBuilder.FLAG_COMPONENTS_V2);
        if (!roles.isEmpty()) {
            payload.add("allowed_mentions", new JsonObjectBuilder()
                    .add("parse", Collections.<String>emptyList())
                    .add("roles", new ArrayList<>(roles)));
        } else {
            payload.add("allowed_mentions", new JsonObjectBuilder()
                    .add("parse", Collections.<String>emptyList()));
        }
        payload.add("components", top);

        DiscordClient.Result res = discord.postWebhookBlocking(
                cfg.getAdminTarget().getId(), cfg.getAdminTarget().getToken(), payload.build());

        if (res.ok()) {
            consecutiveFailures = 0;
            lastSuccessMs = System.currentTimeMillis();
            int d;
            synchronized (this) { d = dropped; dropped = 0; }
            if (d > 0) plugin.getLogger().warning("Admin log queue overflowed, " + d + " event(s) were dropped.");
            return true;
        }

        if (res.status == 429 || res.status == -1 || res.status / 100 == 5) {
            // transient: put the batch back and wait
            synchronized (this) {
                for (int i = batch.size() - 1; i >= 0; i--) queue.addFirst(batch.get(i));
            }
            consecutiveFailures++;
            long wait = res.status == 429 ? res.retryAfterMs : Math.min(60000L, 3000L * consecutiveFailures);
            notBeforeMs = System.currentTimeMillis() + wait;
            return false;
        }

        // 400/401/403/404 etc: retrying the same batch cannot help, drop it
        if (res.status == 401 || res.status == 403 || res.status == 404) {
            plugin.getLogger().warning("Admin webhook rejected (" + res.status
                    + "). Check admin-log.webhook-url and run /monitorx reload.");
            notBeforeMs = System.currentTimeMillis() + 60000L;
        }
        return false;
    }
}
