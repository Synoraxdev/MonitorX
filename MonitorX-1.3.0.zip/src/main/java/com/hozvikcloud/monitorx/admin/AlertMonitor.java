/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.admin;

import com.hozvikcloud.monitorx.config.PluginConfig;
import com.hozvikcloud.monitorx.metrics.MemoryMetrics;
import com.hozvikcloud.monitorx.metrics.TpsTracker;
import com.hozvikcloud.monitorx.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/**
 * Posts "low TPS" / "high RAM" alerts to the admin channel and a recovery message
 * when the value is healthy again. The first minute after start is ignored because
 * TPS is naturally low while the server is still loading.
 */
public class AlertMonitor implements Runnable {

    private static final long GRACE_MS = 60_000L;

    private final JavaPlugin plugin;
    private final PluginConfig cfg;
    private final TpsTracker tps;
    private final AdminEvents events;

    private BukkitTask task;
    private long graceUntil;

    private int tpsBad = 0;
    private long tpsSince = 0;
    private long tpsLastAlert = 0;

    private int ramBad = 0;
    private long ramSince = 0;
    private long ramLastAlert = 0;

    public AlertMonitor(JavaPlugin plugin, PluginConfig cfg, TpsTracker tps, AdminEvents events) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.tps = tps;
        this.events = events;
    }

    public synchronized void start() {
        stop();
        if (!cfg.isAdminEnabled() || !cfg.isAlertsEnabled()) return;
        graceUntil = System.currentTimeMillis() + GRACE_MS;
        long period = cfg.getAlertCheckIntervalSeconds() * 20L;
        task = Bukkit.getScheduler().runTaskTimer(plugin, this, period, period);
    }

    public synchronized void stop() {
        if (task != null) { task.cancel(); task = null; }
        tpsBad = ramBad = 0;
        tpsSince = ramSince = 0;
    }

    @Override
    public void run() {
        long now = System.currentTimeMillis();
        if (now < graceUntil) return;
        long cooldown = cfg.getAlertCooldownSeconds() * 1000L;

        double t = tps.getTps()[0];
        boolean low = t < cfg.getAlertTpsBelow();
        if (low) {
            tpsBad++;
            if (tpsBad >= 2) {
                if (tpsSince == 0) {
                    tpsSince = now;
                    tpsLastAlert = now;
                    events.alert("Low TPS",
                            "TPS dropped to **" + String.format("%.2f", t) + "** (limit "
                                    + String.format("%.1f", cfg.getAlertTpsBelow()) + ").", false);
                } else if (now - tpsLastAlert >= cooldown) {
                    tpsLastAlert = now;
                    events.alert("Low TPS (still)",
                            "TPS is still **" + String.format("%.2f", t) + "** after `"
                                    + TimeUtil.duration(now - tpsSince) + "`.", false);
                }
            }
        } else {
            tpsBad = 0;
            if (tpsSince != 0) {
                events.alert("TPS recovered",
                        "TPS is back to **" + String.format("%.2f", t) + "** after `"
                                + TimeUtil.duration(now - tpsSince) + "` of lag.", true);
                tpsSince = 0;
            }
        }

        MemoryMetrics mem = MemoryMetrics.collect();
        double pct = mem.getHeapUsagePercentage();
        boolean high = pct > cfg.getAlertRamAbovePercent();
        if (high) {
            ramBad++;
            if (ramBad >= 2) {
                String detail = "Heap usage is **" + String.format("%.1f%%", pct) + "** ("
                        + MemoryMetrics.formatBytes(mem.getHeapUsedBytes()) + " / "
                        + MemoryMetrics.formatBytes(mem.getHeapMaxBytes()) + ").";
                if (ramSince == 0) {
                    ramSince = now;
                    ramLastAlert = now;
                    events.alert("High RAM usage", detail, false);
                } else if (now - ramLastAlert >= cooldown) {
                    ramLastAlert = now;
                    events.alert("High RAM usage (still)", detail, false);
                }
            }
        } else {
            ramBad = 0;
            if (ramSince != 0) {
                events.alert("RAM back to normal",
                        "Heap usage is **" + String.format("%.1f%%", pct) + "** after `"
                                + TimeUtil.duration(now - ramSince) + "` of high usage.", true);
                ramSince = 0;
            }
        }
    }
}
