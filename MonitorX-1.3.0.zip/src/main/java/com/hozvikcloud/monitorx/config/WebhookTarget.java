/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.config;

import com.hozvikcloud.monitorx.discord.JsonObjectBuilder;

import java.util.logging.Logger;

/** A parsed Discord webhook plus its optional custom name / avatar. */
public final class WebhookTarget {

    private final String id;
    private final String token;
    private final String name;
    private final String avatarUrl;

    public WebhookTarget(String url, String name, String avatarUrl, Logger log) {
        String[] parts = parseIds(url, log);
        this.id = parts == null ? null : parts[0];
        this.token = parts == null ? null : parts[1];
        this.name = name == null ? "" : name.trim();
        this.avatarUrl = avatarUrl == null ? "" : avatarUrl.trim();
    }

    /** Returns {id, token} or null when the URL is empty/malformed (a warning explains why). */
    public static String[] parseIds(String url, Logger log) {
        if (url == null || url.trim().isEmpty()) return null;
        String clean = url.trim();
        if (clean.toUpperCase().contains("YOUR_") && clean.toUpperCase().contains("_HERE")) {
            return null; // untouched placeholder from the default config
        }
        int q = clean.indexOf('?');
        if (q >= 0) clean = clean.substring(0, q);
        while (clean.endsWith("/")) clean = clean.substring(0, clean.length() - 1);

        if (!clean.matches("(?i)^https://((ptb|canary)\\.)?(discord|discordapp)\\.com/api(/v\\d+)?/webhooks/.+")) {
            warn(log, "Webhook URL must look like https://discord.com/api/webhooks/<id>/<token> (got: "
                    + shorten(url) + ")");
            return null;
        }
        String rest = clean.substring(clean.indexOf("/webhooks/") + "/webhooks/".length());
        int slash = rest.indexOf('/');
        if (slash < 0) {
            warn(log, "Webhook URL is missing the token part (https://discord.com/api/webhooks/<id>/<token>).");
            return null;
        }
        String id = rest.substring(0, slash);
        String token = rest.substring(slash + 1);
        if (!id.matches("\\d{5,25}") || token.isEmpty() || token.contains("/")) {
            warn(log, "Webhook URL has an invalid id or token. Copy it again from Discord (Integrations > Webhooks).");
            return null;
        }
        return new String[]{id, token};
    }

    private static void warn(Logger log, String msg) {
        if (log != null) log.warning(msg);
    }

    /** Never print the secret token in logs. */
    private static String shorten(String url) {
        int i = url.indexOf("/webhooks/");
        return i < 0 ? (url.length() > 30 ? url.substring(0, 30) + "..." : url) : url.substring(0, i + 10) + "...";
    }

    public boolean isConfigured() {
        return id != null && !id.isEmpty() && token != null && !token.isEmpty();
    }

    /** Adds username / avatar_url to a payload when configured. */
    public JsonObjectBuilder applyIdentity(JsonObjectBuilder payload) {
        if (!name.isEmpty()) payload.add("username", name);
        if (avatarUrl.startsWith("http://") || avatarUrl.startsWith("https://")) {
            payload.add("avatar_url", avatarUrl);
        }
        return payload;
    }

    public String getId() { return id; }
    public String getToken() { return token; }
    public String getName() { return name; }
    public String getAvatarUrl() { return avatarUrl; }
}
