/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.data;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

/**
 * Remembers WHICH Discord message is the live dashboard (plugins/MonitorX/dashboard.yml).
 * It lives in its own file, not in config.yml, so replacing or re-saving config.yml can
 * never make the plugin forget the message and post a second one.
 */
public class DashboardStore {

    public static final String FORMAT = "components-v2";

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;
    private final boolean existed;

    public DashboardStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "dashboard.yml");
        this.existed = file.exists();
        this.yml = existed ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
    }

    public boolean existedOnStart() { return existed; }

    public synchronized String getMessageId() { return yml.getString("message-id", ""); }
    public synchronized String getWebhookId() { return yml.getString("webhook-id", ""); }
    public synchronized String getFormat() { return yml.getString("format", ""); }
    public synchronized String getPendingDelete() { return yml.getString("pending-delete", ""); }

    /** Message that now is the dashboard, posted through this webhook. */
    public synchronized void setMessage(String webhookId, String messageId) {
        yml.set("message-id", messageId == null ? "" : messageId);
        yml.set("webhook-id", webhookId == null ? "" : webhookId);
        yml.set("format", FORMAT);
        save();
    }

    /** Forget the current message; optionally queue it for deletion once a new one is posted. */
    public synchronized void clearMessage(boolean deleteOld) {
        String old = getMessageId();
        if (deleteOld && !old.isEmpty()) yml.set("pending-delete", old);
        yml.set("message-id", "");
        save();
    }

    public synchronized void setPendingDelete(String messageId) {
        yml.set("pending-delete", messageId == null ? "" : messageId);
        save();
    }

    private void save() {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "dashboard.yml save failed: " + e.getMessage());
        }
    }
}
