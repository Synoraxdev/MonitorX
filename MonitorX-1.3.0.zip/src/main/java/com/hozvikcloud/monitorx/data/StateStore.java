/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.data;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

/**
 * Remembers when the server started / stopped across restarts (plugins/MonitorX/data.yml).
 * A heartbeat is written regularly; if the file still says "running" on the next
 * start, the previous session ended without a clean shutdown (crash / kill / power loss).
 */
public class StateStore {

    public enum PreviousKind { NONE, CLEAN, CRASH, RELOAD }

    public static final class Previous {
        public final PreviousKind kind;
        public final long startedAt;
        public final long endedAt;   // clean: stop time, crash: last heartbeat
        public Previous(PreviousKind kind, long startedAt, long endedAt) {
            this.kind = kind;
            this.startedAt = startedAt;
            this.endedAt = endedAt;
        }
    }

    private static final long RELOAD_WINDOW_MS = 45_000L;

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;

    public StateStore(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.yml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
    }

    /** Reads the previous session and marks a new one as running. */
    public synchronized Previous begin(long sessionStartMs) {
        long now = System.currentTimeMillis();
        long prevStart = yml.getLong("last-start", 0L);
        long prevBeat = yml.getLong("last-heartbeat", 0L);
        long prevStop = yml.getLong("last-stop", 0L);
        boolean running = yml.getBoolean("running", false);

        Previous prev;
        if (prevStart <= 0) {
            prev = new Previous(PreviousKind.NONE, 0, 0);
        } else if (running && prevStart == sessionStartMs && now - prevBeat < RELOAD_WINDOW_MS) {
            prev = new Previous(PreviousKind.RELOAD, prevStart, prevBeat);
        } else if (running) {
            prev = new Previous(PreviousKind.CRASH, prevStart, prevBeat > 0 ? prevBeat : prevStart);
        } else {
            prev = new Previous(PreviousKind.CLEAN, prevStart, prevStop > 0 ? prevStop : prevBeat);
        }

        yml.set("running", true);
        yml.set("last-start", sessionStartMs);
        yml.set("last-heartbeat", now);
        save();
        return prev;
    }

    public synchronized void heartbeat() {
        yml.set("running", true);
        yml.set("last-heartbeat", System.currentTimeMillis());
        save();
    }

    public synchronized void markStopped() {
        long now = System.currentTimeMillis();
        yml.set("running", false);
        yml.set("last-stop", now);
        yml.set("last-heartbeat", now);
        save();
    }

    private void save() {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "data.yml save failed: " + e.getMessage());
        }
    }
}
