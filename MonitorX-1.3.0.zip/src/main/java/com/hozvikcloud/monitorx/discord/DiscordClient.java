/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.discord;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

// POST once to grab a message id, then PATCH it every refresh. The caller handles
// 404 (message deleted -> repost) and 429 (rate limited -> back off).
// HTTP is done by SimpleHttps so this works on Java 8 and every newer Java.
public class DiscordClient {

    private static final String BASE = "https://discord.com/api/webhooks";
    private static final int CONNECT_TIMEOUT_MS = 6000;
    private static final int READ_TIMEOUT_MS = 8000;

    private final Logger log;
    private final String ua;
    private final ExecutorService io;

    public DiscordClient(Logger log, String pluginVersion) {
        this.log = log;
        this.ua = "MonitorX/" + pluginVersion + " (Minecraft)";
        this.io = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "MonitorX-Discord-IO");
            t.setDaemon(true);
            return t;
        });
    }

    /** Stops the I/O thread. Call after the last request (plugin disable). */
    public void close() {
        io.shutdown();
    }

    private Map<String, String> headers() {
        Map<String, String> h = new HashMap<>();
        h.put("Content-Type", "application/json");
        h.put("User-Agent", ua);
        return h;
    }

    public CompletableFuture<String> postWebhookMessage(String id, String token, String json) {
        if (id == null || token == null) return CompletableFuture.completedFuture(null);
        String url = BASE + "/" + id + "/" + token + "?wait=true&with_components=true";
        return CompletableFuture.supplyAsync(() -> {
            try {
                SimpleHttps.Response resp = SimpleHttps.request("POST", url, headers(), json,
                        CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
                if (resp.status / 100 == 2) {
                    String mid = JsonObjectBuilder.extractStringField(resp.body, "id");
                    log.info("Webhook message posted (id=" + mid + ")");
                    return mid;
                }
                log.warning("Webhook POST " + resp.status + ": " + trim(resp.body));
                return null;
            } catch (Throwable t) {
                log.log(Level.WARNING, "Webhook POST error", t);
                return null;
            }
        }, io);
    }

    /** Outcome of a webhook request. status -1 = network error / no request made. */
    public static final class Result {
        public final int status;
        public final long retryAfterMs;
        public Result(int status, long retryAfterMs) {
            this.status = status;
            this.retryAfterMs = retryAfterMs;
        }
        public boolean ok() { return status / 100 == 2; }
    }

    /** Edits the dashboard message. The caller decides what to do with 404 / 429. */
    public CompletableFuture<Result> editWebhookMessage(String id, String token, String msgId, String json) {
        if (id == null || token == null || msgId == null || msgId.isEmpty()) {
            return CompletableFuture.completedFuture(new Result(-1, 0));
        }
        String url = BASE + "/" + id + "/" + token + "/messages/" + msgId + "?with_components=true";
        return CompletableFuture.supplyAsync(() -> {
            try {
                SimpleHttps.Response resp = SimpleHttps.request("PATCH", url, headers(), json,
                        CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
                int s = resp.status;
                if (s == 401 || s == 403) {
                    log.warning("Webhook rejected (" + s + "). Update discord.webhook-url and reload.");
                } else if (s / 100 != 2 && s != 404 && s != 429) {
                    log.warning("Webhook edit " + s + ": " + trim(resp.body));
                }
                return new Result(s, retryAfterMs(resp));
            } catch (Throwable t) {
                log.warning("Webhook edit error: " + t.getMessage());
                return new Result(-1, 0);
            }
        }, io);
    }

    /** Deletes a message posted by this webhook (used to remove an old dashboard message). */
    public CompletableFuture<Result> deleteWebhookMessage(String id, String token, String msgId) {
        if (id == null || token == null || msgId == null || msgId.isEmpty()) {
            return CompletableFuture.completedFuture(new Result(-1, 0));
        }
        String url = BASE + "/" + id + "/" + token + "/messages/" + msgId;
        return CompletableFuture.supplyAsync(() -> {
            try {
                SimpleHttps.Response resp = SimpleHttps.request("DELETE", url, headers(), null,
                        CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
                return new Result(resp.status, retryAfterMs(resp));
            } catch (Throwable t) {
                log.warning("Webhook delete error: " + t.getMessage());
                return new Result(-1, 0);
            }
        }, io);
    }

    /**
     * Blocking POST used by the admin log (no message id needed). Runs on the calling
     * thread, so call it from an async task or while the plugin is shutting down.
     */
    public Result postWebhookBlocking(String id, String token, String json) {
        if (id == null || token == null) return new Result(-1, 0);
        String url = BASE + "/" + id + "/" + token + "?with_components=true";
        try {
            SimpleHttps.Response resp = SimpleHttps.request("POST", url, headers(), json,
                    CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
            if (resp.status / 100 != 2 && resp.status != 429) {
                log.warning("Admin webhook POST " + resp.status + ": " + trim(resp.body));
            }
            return new Result(resp.status, retryAfterMs(resp));
        } catch (Throwable t) {
            log.warning("Admin webhook POST error: " + t.getMessage());
            return new Result(-1, 0);
        }
    }

    private static long retryAfterMs(SimpleHttps.Response resp) {
        try {
            String v = resp.headers.get("retry-after");
            if (v != null) return Math.max(250L, (long) (Double.parseDouble(v.trim()) * 1000.0));
        } catch (NumberFormatException ignored) {
        }
        return resp.status == 429 ? 2000L : 0L;
    }

    private static String trim(String s) {
        if (s == null) return "";
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
