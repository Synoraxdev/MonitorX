/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.discord;

import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Tiny HTTP/1.1 client that works on every Java version from 8 up.
 *
 * Why it exists: java.net.http (Java 11+) is not available on Java 8, and
 * HttpURLConnection refuses the PATCH method that Discord needs to edit a
 * webhook message. One request per connection ("Connection: close"), hostname
 * verification is on for https, no redirects, no compression.
 */
final class SimpleHttps {

    static final class Response {
        final int status;
        final Map<String, String> headers; // lower-case names
        final String body;

        Response(int status, Map<String, String> headers, String body) {
            this.status = status;
            this.headers = headers;
            this.body = body;
        }
    }

    private static final int MAX_BODY_BYTES = 1024 * 1024;
    private static final int MAX_LINE_BYTES = 16 * 1024;

    private SimpleHttps() {}

    static Response request(String method, String url, Map<String, String> headers, String body,
                            int connectTimeoutMs, int readTimeoutMs) throws IOException {
        return request(method, url, headers, body, connectTimeoutMs, readTimeoutMs, null);
    }

    /** sslFactory == null means the JVM default (used in production). */
    static Response request(String method, String url, Map<String, String> headers, String body,
                            int connectTimeoutMs, int readTimeoutMs,
                            SSLSocketFactory sslFactory) throws IOException {
        URI uri = URI.create(url);
        String scheme = uri.getScheme();
        boolean https = "https".equalsIgnoreCase(scheme);
        if (!https && !"http".equalsIgnoreCase(scheme)) {
            throw new IOException("Unsupported URL scheme: " + scheme);
        }
        String host = uri.getHost();
        if (host == null) throw new IOException("URL has no host");
        int port = uri.getPort() > 0 ? uri.getPort() : (https ? 443 : 80);

        String path = uri.getRawPath();
        if (path == null || path.isEmpty()) path = "/";
        if (uri.getRawQuery() != null) path += "?" + uri.getRawQuery();

        byte[] payload = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);

        Socket plain = new Socket();
        Socket sock = plain;
        try {
            plain.connect(new InetSocketAddress(host, port), connectTimeoutMs);
            plain.setSoTimeout(readTimeoutMs);

            if (https) {
                SSLSocketFactory f = sslFactory != null ? sslFactory
                        : (SSLSocketFactory) SSLSocketFactory.getDefault();
                SSLSocket ssl = (SSLSocket) f.createSocket(plain, host, port, true);
                SSLParameters params = ssl.getSSLParameters();
                params.setEndpointIdentificationAlgorithm("HTTPS"); // verify hostname
                ssl.setSSLParameters(params);
                ssl.startHandshake();
                sock = ssl;
            }

            StringBuilder req = new StringBuilder(256);
            req.append(method).append(' ').append(path).append(" HTTP/1.1\r\n");
            req.append("Host: ").append(uri.getPort() > 0 ? host + ":" + port : host).append("\r\n");
            req.append("Accept: */*\r\n");
            req.append("Connection: close\r\n");
            req.append("Content-Length: ").append(payload.length).append("\r\n");
            if (headers != null) {
                for (Map.Entry<String, String> h : headers.entrySet()) {
                    req.append(h.getKey()).append(": ").append(h.getValue()).append("\r\n");
                }
            }
            req.append("\r\n");

            OutputStream out = sock.getOutputStream();
            out.write(req.toString().getBytes(StandardCharsets.ISO_8859_1));
            if (payload.length > 0) out.write(payload);
            out.flush();

            return readResponse(sock.getInputStream());
        } finally {
            try { sock.close(); } catch (IOException ignored) { }
            if (sock != plain) {
                try { plain.close(); } catch (IOException ignored) { }
            }
        }
    }

    private static Response readResponse(InputStream in) throws IOException {
        String statusLine = readLine(in);
        // Skip any interim "100 Continue" style responses.
        while (statusLine != null && statusLine.startsWith("HTTP/") && isInterim(statusLine)) {
            while (true) {
                String l = readLine(in);
                if (l == null || l.isEmpty()) break;
            }
            statusLine = readLine(in);
        }
        if (statusLine == null || !statusLine.startsWith("HTTP/")) {
            throw new IOException("Bad HTTP status line: " + statusLine);
        }
        String[] parts = statusLine.split(" ", 3);
        if (parts.length < 2) throw new IOException("Bad HTTP status line: " + statusLine);
        int status;
        try {
            status = Integer.parseInt(parts[1].trim());
        } catch (NumberFormatException e) {
            throw new IOException("Bad HTTP status code: " + statusLine);
        }

        Map<String, String> hdrs = new HashMap<>();
        while (true) {
            String line = readLine(in);
            if (line == null || line.isEmpty()) break;
            int c = line.indexOf(':');
            if (c > 0) {
                hdrs.put(line.substring(0, c).trim().toLowerCase(Locale.ROOT), line.substring(c + 1).trim());
            }
        }

        byte[] bodyBytes;
        if (status == 204 || status == 304 || (status >= 100 && status < 200)) {
            bodyBytes = new byte[0];
        } else if ("chunked".equalsIgnoreCase(hdrs.get("transfer-encoding"))) {
            bodyBytes = readChunked(in);
        } else if (hdrs.containsKey("content-length")) {
            long len;
            try {
                len = Long.parseLong(hdrs.get("content-length"));
            } catch (NumberFormatException e) {
                throw new IOException("Bad Content-Length");
            }
            if (len < 0 || len > MAX_BODY_BYTES) throw new IOException("Response too large: " + len);
            bodyBytes = readFully(in, (int) len);
        } else {
            bodyBytes = readToEof(in);
        }
        return new Response(status, hdrs, new String(bodyBytes, StandardCharsets.UTF_8));
    }

    private static boolean isInterim(String statusLine) {
        String[] p = statusLine.split(" ", 3);
        return p.length >= 2 && p[1].length() == 3 && p[1].charAt(0) == '1';
    }

    private static byte[] readChunked(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        while (true) {
            String sizeLine = readLine(in);
            if (sizeLine == null) throw new EOFException("Unexpected EOF in chunked body");
            int semi = sizeLine.indexOf(';');
            if (semi >= 0) sizeLine = sizeLine.substring(0, semi);
            sizeLine = sizeLine.trim();
            if (sizeLine.isEmpty()) continue;
            int size;
            try {
                size = Integer.parseInt(sizeLine, 16);
            } catch (NumberFormatException e) {
                throw new IOException("Bad chunk size: " + sizeLine);
            }
            if (size < 0) throw new IOException("Bad chunk size: " + sizeLine);
            if (size == 0) {
                // trailers until blank line
                while (true) {
                    String t = readLine(in);
                    if (t == null || t.isEmpty()) break;
                }
                break;
            }
            if (out.size() + size > MAX_BODY_BYTES) throw new IOException("Response too large");
            out.write(readFully(in, size), 0, size);
            readLine(in); // CRLF after chunk data
        }
        return out.toByteArray();
    }

    private static byte[] readFully(InputStream in, int len) throws IOException {
        byte[] buf = new byte[len];
        int off = 0;
        while (off < len) {
            int n = in.read(buf, off, len - off);
            if (n < 0) throw new EOFException("Unexpected EOF in body");
            off += n;
        }
        return buf;
    }

    private static byte[] readToEof(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) >= 0) {
            out.write(buf, 0, n);
            if (out.size() > MAX_BODY_BYTES) throw new IOException("Response too large");
        }
        return out.toByteArray();
    }

    /** Reads one CRLF/LF terminated line. Returns null on EOF before any byte. */
    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream line = new ByteArrayOutputStream(64);
        int b;
        boolean any = false;
        while ((b = in.read()) >= 0) {
            any = true;
            if (b == '\n') break;
            if (b != '\r') line.write(b);
            if (line.size() > MAX_LINE_BYTES) throw new IOException("HTTP line too long");
        }
        if (!any) return null;
        return new String(line.toByteArray(), StandardCharsets.ISO_8859_1);
    }
}
