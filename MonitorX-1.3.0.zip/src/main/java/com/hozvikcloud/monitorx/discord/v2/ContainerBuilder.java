/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.discord.v2;

import com.hozvikcloud.monitorx.discord.JsonObjectBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds one Discord Components V2 container (type 17) out of text displays (type 10),
 * separators (type 14) and an optional section with a thumbnail (types 9 + 11).
 * Also counts text characters and components, because Discord limits a V2 message to
 * 4000 characters of text and 40 components in total.
 */
public final class ContainerBuilder {

    public static final int FLAG_COMPONENTS_V2 = 32768;
    private static final int MAX_TEXT = 3000;

    private Integer accentColor;
    private final List<Object> children = new ArrayList<>();
    private int textChars = 0;
    private int components = 1; // the container itself

    public ContainerBuilder accent(Integer color) {
        this.accentColor = color;
        return this;
    }

    public ContainerBuilder text(String markdown) {
        if (markdown == null || markdown.trim().isEmpty()) return this;
        String t = cut(markdown);
        children.add(textDisplay(t));
        textChars += t.length();
        components++;
        return this;
    }

    public ContainerBuilder separator() {
        children.add(new JsonObjectBuilder().add("type", 14));
        components++;
        return this;
    }

    /** Text with a small picture on the right. Falls back to plain text without a url. */
    public ContainerBuilder section(String markdown, String thumbnailUrl) {
        if (thumbnailUrl == null || thumbnailUrl.isEmpty()) return text(markdown);
        String t = cut(markdown == null || markdown.trim().isEmpty() ? "-#" : markdown);
        List<Object> inner = new ArrayList<>();
        inner.add(textDisplay(t));
        JsonObjectBuilder section = new JsonObjectBuilder()
                .add("type", 9)
                .add("components", inner)
                .add("accessory", new JsonObjectBuilder()
                        .add("type", 11)
                        .add("media", new JsonObjectBuilder().add("url", thumbnailUrl)));
        children.add(section);
        textChars += t.length();
        components += 3; // section + text + thumbnail
        return this;
    }

    public JsonObjectBuilder build() {
        JsonObjectBuilder c = new JsonObjectBuilder().add("type", 17);
        if (accentColor != null) c.add("accent_color", accentColor);
        c.add("components", children);
        return c;
    }

    public int getTextChars() { return textChars; }
    public int getComponentCount() { return components; }

    /** A bare top-level text display (used for role pings). */
    public static JsonObjectBuilder topLevelText(String markdown) {
        return textDisplay(markdown);
    }

    private static JsonObjectBuilder textDisplay(String content) {
        return new JsonObjectBuilder().add("type", 10).add("content", content);
    }

    private static String cut(String s) {
        return s.length() <= MAX_TEXT ? s : s.substring(0, MAX_TEXT - 3) + "...";
    }
}
