/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.metrics;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;

// TPS resolution (three tiers): Paper/Purpur native -> Spigot NMS via reflection
// -> built-in tick-delta tracker.
//
// MSPT resolution (two tiers):
//   1. Paper native (getAverageTickTime / getTickTimes) = real tick processing time.
//   2. Fallback on plain Spigot: the gap between two ticks. This is NOT processing
//      time (it is ~50ms on a healthy server), so it is only shown as an estimate
//      and only reported as a number when the server is actually overloaded.
// Reflection is one-shot and cached.
public class TpsTracker implements Runnable {

    private final Plugin plugin;
    private BukkitTask task;

    private static final int HISTORY = 100;
    private final Deque<Long> tickDeltas = new ArrayDeque<>(HISTORY);
    private long deltaSumNs = 0;
    private long lastTickNs = 0;

    private double fallbackTps = 20.0;
    // Average gap between two ticks (ms). Used for fallback TPS and fallback MSPT only.
    private double avgTickIntervalMs = 50.0;

    private static Object nmsServer = null;
    private static Field recentTpsField = null;
    private static boolean reflectionTried = false;

    private Method avgTickTimeMethod = null;   // Paper: double getAverageTickTime() (ms)
    private Method tickTimesMethod = null;     // Paper: long[] getTickTimes() (ns)
    private boolean msptApiResolved = false;

    public TpsTracker(Plugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        this.lastTickNs = System.nanoTime();
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this, 1L, 1L);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    @Override
    public void run() {
        long now = System.nanoTime();
        if (lastTickNs > 0) {
            long delta = now - lastTickNs;
            synchronized (tickDeltas) {
                if (tickDeltas.size() >= HISTORY) deltaSumNs -= tickDeltas.pollFirst();
                tickDeltas.addLast(delta);
                deltaSumNs += delta;
                double avgMs = (deltaSumNs / (double) tickDeltas.size()) / 1_000_000.0;
                avgTickIntervalMs = avgMs;
                fallbackTps = avgMs <= 50.0 ? 20.0 : Math.min(20.0, 1000.0 / avgMs);
            }
        }
        lastTickNs = now;
    }

    public double[] getTps() {
        try {
            Method m = Bukkit.getServer().getClass().getMethod("getTPS");
            Object r = m.invoke(Bukkit.getServer());
            if (r instanceof double[]) return clamp((double[]) r);
        } catch (Throwable ignored) {
        }
        try {
            ensureReflection();
            if (nmsServer != null && recentTpsField != null) {
                double[] r = (double[]) recentTpsField.get(nmsServer);
                if (r != null && r.length >= 3) return clamp(r);
            }
        } catch (Throwable ignored) {
        }
        return new double[]{fallbackTps, fallbackTps, fallbackTps};
    }

    private static double[] clamp(double[] t) {
        return new double[]{
                Math.min(20.0, Math.max(0.0, t[0])),
                Math.min(20.0, Math.max(0.0, t[1])),
                Math.min(20.0, Math.max(0.0, t[2]))
        };
    }

    // TODO: revisit once Paper ships a non-reflective TPS API
    private static synchronized void ensureReflection() {
        if (reflectionTried) return;
        reflectionTried = true;
        try {
            Class<?> craft = Bukkit.getServer().getClass();
            nmsServer = craft.getMethod("getServer").invoke(Bukkit.getServer());
            if (nmsServer != null) recentTpsField = nmsServer.getClass().getField("recentTps");
        } catch (Throwable ignored) {
        }
    }

    // ---- MSPT -------------------------------------------------------------

    private synchronized void resolveMsptApi() {
        if (msptApiResolved) return;
        msptApiResolved = true;
        Class<?> server = Bukkit.getServer().getClass();
        try {
            avgTickTimeMethod = server.getMethod("getAverageTickTime");
        } catch (Throwable ignored) {
        }
        if (avgTickTimeMethod == null) {
            try {
                tickTimesMethod = server.getMethod("getTickTimes");
            } catch (Throwable ignored) {
            }
        }
    }

    /** Real tick processing time in ms from Paper's API, or -1 if not available. */
    private double readNativeMspt() {
        resolveMsptApi();
        try {
            if (avgTickTimeMethod != null) {
                Object r = avgTickTimeMethod.invoke(Bukkit.getServer());
                if (r instanceof Number) {
                    double v = ((Number) r).doubleValue();
                    if (v >= 0.0) return v;
                }
            }
            if (tickTimesMethod != null) {
                Object r = tickTimesMethod.invoke(Bukkit.getServer());
                if (r instanceof long[]) {
                    long sum = 0;
                    int n = 0;
                    for (long ns : (long[]) r) {
                        if (ns > 0) { sum += ns; n++; }   // skip unfilled slots right after startup
                    }
                    if (n > 0) return (sum / (double) n) / 1_000_000.0;
                }
            }
        } catch (Throwable ignored) {
        }
        return -1.0;
    }

    /** MSPT as a number. Real value on Paper; tick-gap estimate on plain Spigot. */
    public double getMspt() {
        double nat = readNativeMspt();
        return nat >= 0.0 ? nat : avgTickIntervalMs;
    }

    /** True when {@link #getMspt()} is real tick processing time (Paper), not an estimate. */
    public boolean isMsptExact() {
        return readNativeMspt() >= 0.0;
    }

    /** Text for Discord / in-game status. Never shows a misleading "~50ms" on a healthy Spigot server. */
    public String getFormattedMspt() {
        double nat = readNativeMspt();
        if (nat >= 0.0) return String.format("%.2f ms", nat);
        double gap = avgTickIntervalMs;
        return gap > 50.0 ? String.format("~%.2f ms (est.)", gap) : "<50 ms (est.)";
    }

    // ---- Uptime -----------------------------------------------------------

    /** Server (JVM) uptime, not the plugin's own uptime - survives plugin reloads. */
    public long getUptimeMillis() {
        return ManagementFactory.getRuntimeMXBean().getUptime();
    }

    public String getFormattedUptime() {
        long s = getUptimeMillis() / 1000;
        long d = s / 86400;
        long h = (s % 86400) / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (d > 0)  return String.format("%dd %02dh %02dm %02ds", d, h, m, sec);
        if (h > 0) return String.format("%02dh %02dm %02ds", h, m, sec);
        return String.format("%02dm %02ds", m, sec);
    }
}
