/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.task;

import com.hozvikcloud.monitorx.config.PluginConfig;
import com.hozvikcloud.monitorx.discord.DiscordClient;
import com.hozvikcloud.monitorx.discord.DiscordPayloadBuilder;
import com.hozvikcloud.monitorx.metrics.ServerMetricsCollector;
import com.hozvikcloud.monitorx.util.ServerNames;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;

// Async timer fires; snapshot is collected on the main thread (Paper 1.21+
// refuses world/player reads off-thread); HTTP I/O then runs back on async.
public class MonitorUpdateTask implements Runnable {

    private final JavaPlugin plugin;
    private final PluginConfig cfg;
    private final DiscordClient discord;
    private final ServerMetricsCollector collector;
    private final DiscordPayloadBuilder builder;
    private final Logger log;

    private BukkitTask scheduled;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile long pausedUntilMs = 0;
    private volatile long lastSuccessMs = 0;
    private volatile int consecutiveFailures = 0;

    public MonitorUpdateTask(JavaPlugin plugin, PluginConfig cfg,
                             DiscordClient discord, ServerMetricsCollector collector) {
        this.plugin = plugin;
        this.cfg = cfg;
        this.discord = discord;
        this.collector = collector;
        this.builder = new DiscordPayloadBuilder(cfg, ServerNames.resolve(plugin, cfg));
        this.log = plugin.getLogger();
    }

    public synchronized void start() {
        stop();
        if (!cfg.isConfigured()) {
            log.warning("Webhook not configured. Set discord.webhook-url in config.yml.");
            return;
        }
        long interval = (long) cfg.getRefreshIntervalSeconds() * 20L;
        scheduled = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this, 20L, interval);
        log.info("Webhook dashboard active. Refresh every " + cfg.getRefreshIntervalSeconds() + "s.");
    }

    public synchronized void stop() {
        if (scheduled != null) { scheduled.cancel(); scheduled = null; }
    }

    /** Epoch ms of the last successful post/edit, 0 if none yet. */
    public long getLastSuccessMs() { return lastSuccessMs; }

    private void onSuccess() {
        lastSuccessMs = System.currentTimeMillis();
        consecutiveFailures = 0;
    }

    /** Exponential backoff for network errors / 5xx: 2x, 4x, 8x ... the refresh interval, max 60s. */
    private void onFailure(String what) {
        int n = Math.min(consecutiveFailures + 1, 10);
        consecutiveFailures = n;
        long wait = Math.min(60_000L, cfg.getRefreshIntervalSeconds() * 1000L * (1L << Math.min(n, 6)));
        pausedUntilMs = System.currentTimeMillis() + wait;
        if (n == 1 || n % 5 == 0) {
            log.warning(what + " failed (" + n + " in a row) - retrying in " + (wait / 1000) + "s.");
        }
    }

    public void forceUpdate() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, this);
    }

    @Override
    public void run() {
        if (!cfg.isConfigured()) return;
        if (System.currentTimeMillis() < pausedUntilMs) return;
        if (!busy.compareAndSet(false, true)) return;
        Bukkit.getScheduler().runTask(plugin, this::collectOnMainThread);
    }

    private void collectOnMainThread() {
        ServerMetricsCollector.Snapshot snap;
        try {
            snap = collector.collectSnapshot(true);
        } catch (Throwable t) {
            log.warning("Snapshot collection failed: " + t.getMessage());
            busy.set(false);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> dispatch(snap));
    }

    private void dispatch(ServerMetricsCollector.Snapshot snap) {
        try {
            String json = builder.buildLiveDashboardPayload(snap);
            String mid = cfg.getMessageId();

            if (mid == null || mid.isEmpty()) {
                log.info("No saved message id - posting initial webhook message.");
                discord.postWebhookMessage(cfg.getWebhookId(), cfg.getWebhookToken(), json)
                        .thenAccept(newId -> {
                            if (newId != null && !newId.isEmpty()) {
                                onSuccess();
                                cfg.setMessageId(newId);
                                log.info("Dashboard message saved (id=" + newId + ").");
                            } else {
                                onFailure("Initial post");
                            }
                            busy.set(false);
                        });
            } else {
                discord.editWebhookMessage(cfg.getWebhookId(), cfg.getWebhookToken(), mid, json)
                        .thenAccept(res -> {
                            if (res.ok()) {
                                onSuccess();
                            } else if (res.status == 404) {
                                // Message was deleted in Discord: forget it, next cycle posts a new one.
                                log.warning("Dashboard message " + mid + " was deleted - posting a new one.");
                                cfg.setMessageId("");
                            } else if (res.status == 429) {
                                pausedUntilMs = System.currentTimeMillis() + res.retryAfterMs;
                                log.warning("Rate limited by Discord, pausing updates for "
                                        + (res.retryAfterMs / 1000.0) + "s. Raise monitor.refresh-interval-seconds if this repeats.");
                            } else if (res.status == 401 || res.status == 403) {
                                pausedUntilMs = System.currentTimeMillis() + 60_000L; // bad webhook, already logged
                            } else {
                                onFailure("Dashboard update");
                            }
                            busy.set(false);
                        });
            }
        } catch (Throwable t) {
            log.warning("Update cycle error: " + t.getMessage());
            busy.set(false);
        }
    }

    public void sendShutdownStatus() {
        if (!cfg.isConfigured()) return;
        pausedUntilMs = 0;
        String mid = cfg.getMessageId();
        if (mid == null || mid.isEmpty()) return;
        try {
            ServerMetricsCollector.Snapshot snap = collector.collectSnapshot(false);
            String json = builder.buildLiveDashboardPayload(snap);
            discord.editWebhookMessage(cfg.getWebhookId(), cfg.getWebhookToken(), mid, json).join();
            log.info("Shutdown status pushed.");
        } catch (Throwable ignored) {
        }
    }
}
