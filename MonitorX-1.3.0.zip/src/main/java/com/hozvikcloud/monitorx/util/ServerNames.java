/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.util;

import com.hozvikcloud.monitorx.config.PluginConfig;
import org.bukkit.plugin.java.JavaPlugin;

public final class ServerNames {

    private ServerNames() {}

    /** monitor.server-name if set, otherwise ip:port (0.0.0.0:port when the ip is unbound). */
    public static String resolve(JavaPlugin plugin, PluginConfig cfg) {
        if (cfg != null && !cfg.getServerName().isEmpty()) return cfg.getServerName();
        try {
            String ip = plugin.getServer().getIp();
            int port = plugin.getServer().getPort();
            if (ip != null && !ip.isEmpty() && !"0.0.0.0".equals(ip) && !"127.0.0.1".equals(ip)) {
                return ip + ":" + port;
            }
            return "0.0.0.0:" + port;
        } catch (Throwable t) {
            return "Minecraft Server";
        }
    }
}
