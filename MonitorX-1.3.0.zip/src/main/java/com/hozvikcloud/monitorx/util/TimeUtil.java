/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.util;

import java.lang.management.ManagementFactory;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class TimeUtil {

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm:ss a z", Locale.ENGLISH);

    private TimeUtil() {}

    /** Start time of the server process (epoch ms). */
    public static long jvmStartMs() {
        try {
            return ManagementFactory.getRuntimeMXBean().getStartTime();
        } catch (Throwable t) {
            return System.currentTimeMillis();
        }
    }

    /** "2d 3h 04m 29s" style duration. */
    public static String duration(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        long d = s / 86400; s %= 86400;
        long h = s / 3600;  s %= 3600;
        long m = s / 60;    s %= 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (d > 0 || h > 0) sb.append(h).append("h ");
        if (d > 0 || h > 0 || m > 0) sb.append(String.format("%02dm ", m));
        sb.append(String.format("%02ds", s));
        return sb.toString();
    }

    public static ZoneId zone(String id) {
        if (id == null || id.trim().isEmpty()) return ZoneId.systemDefault();
        try {
            return ZoneId.of(id.trim());
        } catch (Throwable t) {
            return ZoneId.systemDefault();
        }
    }

    /** Fixed-zone readable time, e.g. "30 Oct 2026, 01:05:22 PM IST". */
    public static String format(long epochMs, ZoneId zone) {
        return FMT.format(Instant.ofEpochMilli(epochMs).atZone(zone));
    }

    /** Discord relative timestamp tag, renders as "3 minutes ago" and keeps counting. */
    public static String rel(long epochMs) {
        return "<t:" + (epochMs / 1000) + ":R>";
    }

    /** "`30 Oct 2026, 01:05:22 PM IST` (<t:..:R>)" */
    public static String stamp(long epochMs, ZoneId zone) {
        return "`" + format(epochMs, zone) + "` (" + rel(epochMs) + ")";
    }
}
