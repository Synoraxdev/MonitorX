/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.ZoneId;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.hozvikcloud.monitorx.data.DashboardStore;
import com.hozvikcloud.monitorx.util.TimeUtil;

public class PluginConfig {

    private final JavaPlugin plugin;
    private FileConfiguration raw;

    // ---- monitor webhook (live dashboard) ----
    private String webhookUrl;
    private String webhookId;
    private String webhookToken;
    private String webhookName = "";
    private String webhookAvatarUrl = "";
    private final DashboardStore store;

    private int refreshIntervalSeconds = 5;
    private String embedColor = "#2B2D31";
    private int progressBarLength = 12;
    private boolean showResources = true;
    private boolean showConfiguration = true;
    private boolean showLiveStats = true;
    private boolean showActions = true;
    private boolean showWorldDetails = true;
    private String serverName = "";
    private boolean showTimestamps = true;
    private String footerText = "";
    private boolean showPlayerNames = false;
    private int maxPlayerNames = 20;

    // ---- "Server Info" part at the bottom of the dashboard ----
    private boolean showServerInfo = true;
    private boolean showMotd = true;
    private boolean showMembers = true;
    private boolean showServerDetails = true;

    private final Map<String, String> emojiMap = new HashMap<>();

    // ---- admin webhook (event log) ----
    private boolean adminEnabled = false;
    private WebhookTarget adminTarget;
    private ZoneId timeZone = ZoneId.systemDefault();
    private String mentionRoleId = "";
    private boolean mentionOnCrash = true;
    private boolean mentionOnStop = false;
    private boolean mentionOnAlert = true;
    private boolean showIp = false;
    private boolean playerHeads = true;
    private int maxListedPlayers = 40;

    private boolean evServerStatus = true;
    private boolean evPlayerJoin = true;
    private boolean evPlayerQuit = true;
    private boolean evPlayerKick = true;
    private boolean evPlayerList = true;
    private boolean evAdminCommands = true;
    private boolean evConsoleCommands = true;
    private boolean evGamemode = true;

    private String adminPermission = "monitorx.admin";
    private boolean logAllPlayerCommands = false;
    private final Set<String> ignoredCommands = new HashSet<>();
    private final Set<String> highlightCommands = new HashSet<>();

    private boolean alertsEnabled = true;
    private double alertTpsBelow = 15.0;
    private double alertRamAbovePercent = 90.0;
    private int alertCooldownSeconds = 300;
    private int alertCheckIntervalSeconds = 10;

    public PluginConfig(JavaPlugin plugin) {
        this.plugin = plugin;
        this.store = new DashboardStore(plugin);
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.raw = plugin.getConfig();

        webhookUrl = raw.getString("discord.webhook-url", "").trim();
        webhookName = raw.getString("discord.webhook-name", "").trim();
        webhookAvatarUrl = raw.getString("discord.webhook-avatar-url", "").trim();
        parseWebhook();
        migrateLegacyMessage();

        refreshIntervalSeconds = Math.max(1, raw.getInt("monitor.refresh-interval-seconds", 5));
        embedColor = raw.getString("monitor.embed-color", "#2B2D31").trim();
        progressBarLength = Math.max(5, Math.min(20, raw.getInt("monitor.progress-bar-length", 12)));

        showResources     = raw.getBoolean("monitor.show-resources", true);
        showConfiguration = raw.getBoolean("monitor.show-configuration", true);
        showLiveStats     = raw.getBoolean("monitor.show-live-stats", true);
        showActions       = raw.getBoolean("monitor.show-actions", true);
        showWorldDetails  = raw.getBoolean("monitor.show-world-details", true);
        serverName        = raw.getString("monitor.server-name", "").trim();
        showTimestamps    = raw.getBoolean("monitor.show-timestamps", true);
        footerText        = raw.getString("monitor.footer-text", "").trim();
        showPlayerNames   = raw.getBoolean("monitor.show-player-names", false);
        maxPlayerNames    = Math.max(1, Math.min(50, raw.getInt("monitor.max-player-names", 20)));

        showServerInfo    = raw.getBoolean("monitor.server-info.enabled", true);
        showMotd          = raw.getBoolean("monitor.server-info.show-motd", true);
        showMembers       = raw.getBoolean("monitor.server-info.show-members", true);
        showServerDetails = raw.getBoolean("monitor.server-info.show-details", true);

        loadEmojis();
        loadAdmin();
    }

    private void loadAdmin() {
        adminEnabled = raw.getBoolean("admin-log.enabled", false);
        adminTarget = new WebhookTarget(
                raw.getString("admin-log.webhook-url", ""),
                raw.getString("admin-log.webhook-name", "MonitorX Admin"),
                raw.getString("admin-log.webhook-avatar-url", ""),
                plugin.getLogger());
        timeZone = TimeUtil.zone(raw.getString("admin-log.time-zone", ""));
        showIp = raw.getBoolean("admin-log.show-ip", false);
        playerHeads = raw.getBoolean("admin-log.player-heads", true);
        maxListedPlayers = Math.max(5, Math.min(80, raw.getInt("admin-log.max-listed-players", 40)));

        mentionRoleId = raw.getString("admin-log.mention.role-id", "").trim();
        if (!mentionRoleId.matches("\\d{5,25}")) mentionRoleId = "";
        mentionOnCrash = raw.getBoolean("admin-log.mention.on-crash", true);
        mentionOnStop  = raw.getBoolean("admin-log.mention.on-stop", false);
        mentionOnAlert = raw.getBoolean("admin-log.mention.on-alert", true);

        evServerStatus    = raw.getBoolean("admin-log.events.server-status", true);
        evPlayerJoin      = raw.getBoolean("admin-log.events.player-join", true);
        evPlayerQuit      = raw.getBoolean("admin-log.events.player-quit", true);
        evPlayerKick      = raw.getBoolean("admin-log.events.player-kick", true);
        evPlayerList      = raw.getBoolean("admin-log.events.player-list", true);
        evAdminCommands   = raw.getBoolean("admin-log.events.admin-commands", true);
        evConsoleCommands = raw.getBoolean("admin-log.events.console-commands", true);
        evGamemode        = raw.getBoolean("admin-log.events.gamemode-change", true);

        adminPermission = raw.getString("admin-log.commands.admin-permission", "monitorx.admin").trim();
        logAllPlayerCommands = raw.getBoolean("admin-log.commands.log-all-players", false);
        fillLowerSet(ignoredCommands, raw.getStringList("admin-log.commands.ignored"));
        fillLowerSet(highlightCommands, raw.getStringList("admin-log.commands.highlight"));

        alertsEnabled = raw.getBoolean("admin-log.alerts.enabled", true);
        alertTpsBelow = raw.getDouble("admin-log.alerts.tps-below", 15.0);
        alertRamAbovePercent = raw.getDouble("admin-log.alerts.ram-above-percent", 90.0);
        alertCooldownSeconds = Math.max(30, raw.getInt("admin-log.alerts.cooldown-seconds", 300));
        alertCheckIntervalSeconds = Math.max(2, raw.getInt("admin-log.alerts.check-interval-seconds", 10));
    }

    private static void fillLowerSet(Set<String> target, java.util.List<String> src) {
        target.clear();
        if (src == null) return;
        for (String s : src) {
            if (s == null) continue;
            String c = s.trim().toLowerCase(Locale.ROOT);
            if (c.startsWith("/")) c = c.substring(1);
            if (!c.isEmpty()) target.add(c);
        }
    }

    private void loadEmojis() {
        emojiMap.clear();
        for (String k : new String[]{
                "title", "resources", "configuration", "live-stats", "players", "worlds",
                "status-online", "status-offline", "cpu", "memory", "disk", "ram", "storage",
                "jvm-heap", "software", "bukkit", "tps", "mspt",
                "players-online", "chunks", "entities",
                "server-info", "motd", "members", "details"}) {
            emojiMap.put(k, "");
        }
        if (!raw.isConfigurationSection("monitor.emojis")) return;
        ConfigurationSection sec = raw.getConfigurationSection("monitor.emojis");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            String v = sec.getString(key);
            if (v != null) emojiMap.put(key, v);
        }
    }

    private void parseWebhook() {
        webhookId = null;
        webhookToken = null;
        String[] ids = WebhookTarget.parseIds(webhookUrl, plugin.getLogger());
        if (ids != null) {
            webhookId = ids[0];
            webhookToken = ids[1];
        }
    }

    public boolean isConfigured() {
        return webhookId != null && !webhookId.isEmpty()
                && webhookToken != null && !webhookToken.isEmpty();
    }

    /**
     * Older versions kept the message id in config.yml. Move it over once: a message from
     * before the Components V2 layout cannot be edited, so it is queued for deletion and
     * replaced by one new message.
     */
    private void migrateLegacyMessage() {
        if (store.existedOnStart() || !store.getMessageId().isEmpty()) return;
        String legacy = raw.getString("discord.message-id", "").trim();
        if (legacy.isEmpty()) return;
        if ("components-v2".equals(raw.getString("discord.message-format", ""))) {
            store.setMessage(webhookId == null ? "" : webhookId, legacy);
        } else {
            plugin.getLogger().info("Old embed dashboard message found - it will be replaced by one Components V2 message.");
            store.setPendingDelete(legacy);
        }
    }

    /** Id of the live dashboard message, "" when none (or when it belongs to another webhook). */
    public String getMessageId() {
        String id = store.getMessageId();
        if (id.isEmpty()) return "";
        String owner = store.getWebhookId();
        if (!owner.isEmpty() && webhookId != null && !owner.equals(webhookId)) return "";
        return id;
    }

    public void setMessageId(String id) {
        if (id == null || id.trim().isEmpty()) store.clearMessage(false);
        else store.setMessage(webhookId, id.trim());
    }

    /** /monitorx reset: post a new dashboard message and delete the old one afterwards. */
    public void requestFreshMessage() { store.clearMessage(true); }

    public String getPendingDelete() { return store.getPendingDelete(); }
    public void clearPendingDelete() { store.setPendingDelete(""); }

    // ---- monitor getters ----
    public String getWebhookUrl() { return webhookUrl; }
    public String getWebhookId() { return webhookId; }
    public String getWebhookToken() { return webhookToken; }
    public String getWebhookName() { return webhookName; }
    public String getWebhookAvatarUrl() { return webhookAvatarUrl; }
    public int getRefreshIntervalSeconds() { return refreshIntervalSeconds; }
    public String getEmbedColor() { return embedColor; }
    public int getProgressBarLengthSafe() { return progressBarLength; }
    public boolean isShowWorldDetailsSafe() { return showWorldDetails; }
    public boolean isShowResources() { return showResources; }
    public boolean isShowConfiguration() { return showConfiguration; }
    public boolean isShowLiveStats() { return showLiveStats; }
    public boolean isShowActions() { return showActions; }
    public String getServerName() { return serverName; }
    public boolean isShowTimestamps() { return showTimestamps; }
    public String getFooterText() { return footerText; }
    public boolean isShowPlayerNames() { return showPlayerNames; }
    public int getMaxPlayerNames() { return maxPlayerNames; }
    public boolean isShowServerInfo() { return showServerInfo; }
    public boolean isShowMotd() { return showMotd; }
    public boolean isShowMembers() { return showMembers; }
    public boolean isShowServerDetails() { return showServerDetails; }

    public String emoji(String key) {
        return emojiMap.getOrDefault(key, "");
    }

    // ---- admin getters ----
    public boolean isAdminEnabled() { return adminEnabled && adminTarget != null && adminTarget.isConfigured(); }
    public boolean isAdminSwitchedOn() { return adminEnabled; }
    public WebhookTarget getAdminTarget() { return adminTarget; }
    public ZoneId getTimeZone() { return timeZone; }
    public String getMentionRoleId() { return mentionRoleId; }
    public boolean isMentionOnCrash() { return mentionOnCrash; }
    public boolean isMentionOnStop() { return mentionOnStop; }
    public boolean isMentionOnAlert() { return mentionOnAlert; }
    public boolean isShowIp() { return showIp; }
    public boolean isPlayerHeads() { return playerHeads; }
    public int getMaxListedPlayers() { return maxListedPlayers; }

    public boolean isEvServerStatus() { return evServerStatus; }
    public boolean isEvPlayerJoin() { return evPlayerJoin; }
    public boolean isEvPlayerQuit() { return evPlayerQuit; }
    public boolean isEvPlayerKick() { return evPlayerKick; }
    public boolean isEvPlayerList() { return evPlayerList; }
    public boolean isEvAdminCommands() { return evAdminCommands; }
    public boolean isEvConsoleCommands() { return evConsoleCommands; }
    public boolean isEvGamemode() { return evGamemode; }

    public String getAdminPermission() { return adminPermission; }
    public boolean isLogAllPlayerCommands() { return logAllPlayerCommands; }
    public boolean isCommandIgnored(String base) { return ignoredCommands.contains(base); }
    public boolean isCommandHighlighted(String base) { return highlightCommands.contains(base); }

    public boolean isAlertsEnabled() { return alertsEnabled; }
    public double getAlertTpsBelow() { return alertTpsBelow; }
    public double getAlertRamAbovePercent() { return alertRamAbovePercent; }
    public int getAlertCooldownSeconds() { return alertCooldownSeconds; }
    public int getAlertCheckIntervalSeconds() { return alertCheckIntervalSeconds; }
}
