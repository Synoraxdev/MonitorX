/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.discord;

import com.hozvikcloud.monitorx.config.PluginConfig;
import com.hozvikcloud.monitorx.discord.v2.ContainerBuilder;
import com.hozvikcloud.monitorx.metrics.MemoryMetrics;
import com.hozvikcloud.monitorx.metrics.NetworkAndPlayerMetrics;
import com.hozvikcloud.monitorx.metrics.ServerInfoMetrics;
import com.hozvikcloud.monitorx.metrics.ServerMetricsCollector;
import com.hozvikcloud.monitorx.metrics.WorldMetrics;
import com.hozvikcloud.monitorx.util.TimeUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Builds the live dashboard as a Discord Components V2 message (containers + text + separators). */
public class DiscordPayloadBuilder {

    private static final String DOT = "`・✿`"; // `・✿`

    private final PluginConfig cfg;
    private final String serverName;

    public DiscordPayloadBuilder(PluginConfig cfg, String serverName) {
        this.cfg = cfg;
        this.serverName = (serverName == null || serverName.isEmpty()) ? "Minecraft Server" : serverName;
    }

    // Returns "emoji " or "" depending on config.
    private String e(String key) {
        String em = cfg.emoji(key);
        return em.isEmpty() ? "" : em + " ";
    }

    /** "-# `・✿` **Label :** body" */
    private static String bullet(String label, String body) {
        return "-# " + DOT + " **" + label + " :** " + body;
    }

    /** "-# **Label** : `value`" */
    private static String item(String label, String value) {
        return "**" + label + "** : `" + value + "`";
    }

    public String buildLiveDashboardPayload(ServerMetricsCollector.Snapshot snap) {
        long now = System.currentTimeMillis();
        long startMs = TimeUtil.jvmStartMs();

        Integer accent = snap.isOnline() ? parseHex(cfg.getEmbedColor()) : Integer.valueOf(0xE74C3C);

        // ================= Container 1: status + resources + stats =================
        ContainerBuilder main = new ContainerBuilder().accent(accent);
        main.text("**" + e("title") + serverName + " | Live Usage**");
        main.separator();

        if (cfg.isShowTimestamps()) {
            if (snap.isOnline()) {
                main.text("-# **Last updated** : " + TimeUtil.rel(now) + " [ <t:" + (now / 1000) + ":F> ]");
            } else {
                main.text("-# **Went offline** : " + TimeUtil.stamp(now, cfg.getTimeZone()));
            }
            main.separator();
        }

        StringBuilder status = new StringBuilder();
        if (snap.isOnline()) {
            status.append(bullet("Status", e("status-online") + "`ONLINE`  ・  **Uptime** `" + snap.getUptime() + "`"));
            if (cfg.isShowTimestamps()) {
                status.append("\n").append(bullet("Online since", TimeUtil.stamp(startMs, cfg.getTimeZone())));
            }
        } else {
            status.append(bullet("Status", e("status-offline") + "`OFFLINE`  ・  **Last uptime** `" + snap.getUptime() + "`"));
            if (cfg.isShowTimestamps()) {
                status.append("\n").append(bullet("Was online since", TimeUtil.stamp(startMs, cfg.getTimeZone())));
            }
        }
        main.text(status.toString());

        if (cfg.isShowResources()) {
            StringBuilder v = new StringBuilder();
            v.append(bullet(e("resources") + "Resources", "")).append("\n");
            v.append("-# ").append(e("ram")).append(item("RAM", MemoryMetrics.formatBytes(snap.getMemory().getSystemTotalBytes())))
                    .append("  ・  ").append(e("cpu")).append(item("CPU", snap.getCpu().getAvailableProcessors() + " Cores")).append("\n");
            v.append("-# ").append(e("storage")).append(item("Storage", MemoryMetrics.formatBytes(snap.getDisk().getTotalSpaceBytes())))
                    .append("  ・  ").append(e("jvm-heap")).append(item("JVM Heap", MemoryMetrics.formatBytes(snap.getMemory().getHeapMaxBytes())));
            main.text(v.toString());
        }

        if (cfg.isShowConfiguration()) {
            double[] t = snap.getTps();
            String tpsIcon = t[0] >= 19.0 ? e("status-online") : (t[0] >= 15.0 ? "" : e("status-offline"));
            StringBuilder v = new StringBuilder();
            v.append(bullet(e("configuration") + "Configuration", "")).append("\n");
            v.append("-# ").append(e("software")).append(item("Software", snap.getServerVersion())).append("\n");
            v.append("-# ").append(e("bukkit")).append(item("Bukkit", snap.getBukkitVersion())).append("\n");
            v.append("-# ").append(e("tps")).append("**TPS (1m)** : ").append(tpsIcon)
                    .append("`").append(String.format("%.2f", t[0])).append("`")
                    .append("  ・  ").append(e("mspt")).append(item("MSPT", snap.getMsptDisplay()));
            main.text(v.toString());
        }

        if (cfg.isShowLiveStats()) {
            StringBuilder v = new StringBuilder();
            double pcpu = Math.max(0, Math.min(100, snap.getCpu().getProcessCpuLoad()));
            String cpuStr = snap.getCpu().getProcessCpuLoad() >= 0
                    ? String.format("%.1f%%", snap.getCpu().getProcessCpuLoad()) : "N/A";
            MemoryMetrics mem = snap.getMemory();
            double memP = mem.getHeapUsagePercentage();
            double diskP = snap.getDisk().getUsedPercentage();
            v.append(bullet(e("live-stats") + "Live Stats", "")).append("\n");
            v.append("-# ").append(e("cpu")).append(item("CPU", cpuStr)).append(" ").append(miniBar(pcpu, 8)).append("\n");
            v.append("-# ").append(e("memory")).append(item("Memory", MemoryMetrics.formatBytes(mem.getHeapUsedBytes())
                    + " / " + MemoryMetrics.formatBytes(mem.getHeapMaxBytes())))
                    .append(" (").append(String.format("%.1f%%", memP)).append(") ").append(miniBar(memP, 8)).append("\n");
            v.append("-# ").append(e("disk")).append(item("Disk", MemoryMetrics.formatBytes(snap.getDisk().getUsedSpaceBytes())
                    + " / " + MemoryMetrics.formatBytes(snap.getDisk().getTotalSpaceBytes())))
                    .append(" (").append(String.format("%.1f%%", diskP)).append(") ").append(miniBar(diskP, 8));
            main.text(v.toString());
        }

        // ================= Container 2: players + worlds + footer =================
        ContainerBuilder second = new ContainerBuilder().accent(accent);
        boolean secondUsed = false;

        if (cfg.isShowActions()) {
            NetworkAndPlayerMetrics net = snap.getNetwork();
            StringBuilder pv = new StringBuilder();
            pv.append(bullet(e("players") + "Players", ""))
                    .append("\n-# ").append(e("players-online"))
                    .append(item("Players Online", net.getOnlinePlayerCount() + " / " + net.getMaxPlayers()));
            if (cfg.isShowPlayerNames() && snap.isOnline() && !net.getPlayerList().isEmpty()) {
                List<NetworkAndPlayerMetrics.PlayerEntry> list = new ArrayList<>(net.getPlayerList());
                Collections.sort(list, new Comparator<NetworkAndPlayerMetrics.PlayerEntry>() {
                    @Override
                    public int compare(NetworkAndPlayerMetrics.PlayerEntry a, NetworkAndPlayerMetrics.PlayerEntry b) {
                        return a.getName().compareToIgnoreCase(b.getName());
                    }
                });
                pv.append("\n-# ");
                int shown = 0;
                for (NetworkAndPlayerMetrics.PlayerEntry pe : list) {
                    String piece = (shown == 0 ? "" : ", ") + "`" + pe.getName().replace("`", "'")
                            + " " + pe.getPing() + "ms`";
                    if (shown >= cfg.getMaxPlayerNames() || pv.length() + piece.length() > 900) break;
                    pv.append(piece);
                    shown++;
                }
                if (shown < list.size()) pv.append(" +").append(list.size() - shown).append(" more");
            }
            second.text(pv.toString());
            secondUsed = true;
        }

        if (cfg.isShowWorldDetailsSafe()) {
            WorldMetrics wm = snap.getWorlds();
            StringBuilder v = new StringBuilder();
            v.append(bullet(e("worlds") + "Worlds", "")).append("\n-# ")
                    .append(e("chunks")).append(item("Chunks", String.valueOf(wm.getTotalLoadedChunks())))
                    .append("  ・  ").append(e("entities")).append(item("Entities", String.valueOf(wm.getTotalEntities())));
            if (wm.getWorlds().size() <= 6) {
                v.append("\n-# ");
                int i = 0;
                for (WorldMetrics.WorldDetail wd : wm.getWorlds()) {
                    if (i++ > 0) v.append("  ・  ");
                    v.append("`").append(wd.getName()).append("` : ")
                            .append(wd.getLoadedChunks()).append("c / ")
                            .append(wd.getEntityCount()).append("e");
                }
            }
            if (secondUsed) second.separator();
            second.text(v.toString());
            secondUsed = true;
        }

        if (cfg.isShowServerInfo()) {
            String info = buildServerInfo(snap.getServerInfo());
            if (!info.isEmpty()) {
                if (secondUsed) second.separator();
                second.text(info);
                secondUsed = true;
            }
        }

        if (!cfg.getFooterText().isEmpty()) {
            if (secondUsed) second.separator();
            second.text("-# " + cfg.getFooterText());
            secondUsed = true;
        }

        List<Object> top = new ArrayList<>();
        top.add(main.build());
        if (secondUsed) top.add(second.build());

        // username / avatar_url are applied by Discord only when the message is first
        // posted; edits ignore them. Empty values keep the webhook's own name/avatar.
        JsonObjectBuilder payload = new JsonObjectBuilder();
        if (!cfg.getWebhookName().isEmpty()) {
            payload.add("username", cfg.getWebhookName());
        }
        if (cfg.getWebhookAvatarUrl().startsWith("http://") || cfg.getWebhookAvatarUrl().startsWith("https://")) {
            payload.add("avatar_url", cfg.getWebhookAvatarUrl());
        }
        return payload
                .add("flags", ContainerBuilder.FLAG_COMPONENTS_V2)
                .add("components", top)
                .build();
    }

    /** Server Info: MOTD, total members joined and a few basic server details. */
    private String buildServerInfo(ServerInfoMetrics si) {
        if (si == null) return "";
        StringBuilder v = new StringBuilder();
        v.append(bullet(e("server-info") + "Server Info", ""));

        if (cfg.isShowMotd()) {
            String motd = clean(si.getMotd(), 120);
            if (!motd.isEmpty()) {
                v.append("\n-# ").append(e("motd")).append(item("MOTD", motd));
            }
        }

        if (cfg.isShowMembers()) {
            String total = si.isMembersReady() ? String.format("%,d", si.getTotalMembers()) : "loading...";
            v.append("\n-# ").append(e("members")).append(item("Total Members Joined", total));
        }

        if (cfg.isShowServerDetails()) {
            StringBuilder d1 = new StringBuilder();
            if (!si.getMinecraftVersion().isEmpty()) d1.append(item("Version", si.getMinecraftVersion()));
            if (!si.getDefaultGamemode().isEmpty()) appendSep(d1).append(item("Gamemode", si.getDefaultGamemode()));
            if (!si.getDifficulty().isEmpty()) appendSep(d1).append(item("Difficulty", si.getDifficulty()));
            if (d1.length() > 0) v.append("\n-# ").append(e("details")).append(d1);

            StringBuilder d2 = new StringBuilder();
            d2.append(item("Online Mode", si.isOnlineMode() ? "ON" : "OFF"));
            appendSep(d2).append(item("Whitelist", si.isWhitelist() ? "ON" : "OFF"));
            appendSep(d2).append(item("Plugins", String.valueOf(si.getPluginCount())));
            appendSep(d2).append(item("Worlds", String.valueOf(si.getWorldCount())));
            if (si.getViewDistance() > 0) appendSep(d2).append(item("View Dist", si.getViewDistance() + " chunks"));
            v.append("\n-# ").append(d2);
        }
        return v.toString();
    }

    private static StringBuilder appendSep(StringBuilder sb) {
        return sb.length() == 0 ? sb : sb.append("  ・  ");
    }

    /** One line, no backticks (they would break the code style), cut to max characters. */
    private static String clean(String raw, int max) {
        if (raw == null) return "";
        String t = raw.replace("`", "'").replace("\r", "").replace("\n", " | ").trim();
        if (t.length() > max) t = t.substring(0, max - 1) + "…";
        return t;
    }

    private static String miniBar(double percent, int width) {
        if (width < 1) width = 1;
        double c = Math.max(0, Math.min(100, percent));
        int filled = (int) Math.round(c / 100.0 * width);
        StringBuilder sb = new StringBuilder(width + 2);
        sb.append('[');
        for (int i = 0; i < width; i++) sb.append(i < filled ? '▰' : '▱');
        sb.append(']');
        return sb.toString();
    }

    /** Empty string = no accent colour bar; invalid = default dark grey. */
    private static Integer parseHex(String hex) {
        if (hex == null) return 0x2B2D31;
        String c = hex.trim().replace("#", "");
        if (c.isEmpty()) return null;
        try {
            return Integer.parseInt(c, 16);
        } catch (NumberFormatException ex) {
            return 0x2B2D31;
        }
    }
}
