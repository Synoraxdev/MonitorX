/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.metrics;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Counts every unique member that has ever joined the server. A member is counted once,
 * the first time they join; rejoining never adds to the total.
 *
 * Known members are stored in plugins/MonitorX/members.txt (one UUID per line) and, on start,
 * also read from the server's own player data, so existing servers get the right total at once.
 */
public class PlayerStats implements Listener {

    private final JavaPlugin plugin;
    private final File file;
    private final Set<UUID> members = Collections.newSetFromMap(new ConcurrentHashMap<UUID, Boolean>());
    private final Object fileLock = new Object();
    private volatile boolean ready = false;

    public PlayerStats(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "members.txt");
    }

    public void start() {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, new Runnable() {
            @Override public void run() { load(); }
        });
    }

    private void load() {
        try {
            loadFile();
            seedFromServer();
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not load the member list: " + t.getMessage());
        } finally {
            ready = true;
        }
    }

    private void loadFile() {
        if (!file.exists()) return;
        BufferedReader r = null;
        try {
            r = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try { members.add(UUID.fromString(line)); } catch (IllegalArgumentException ignored) { }
            }
        } catch (IOException e) {
            plugin.getLogger().warning("members.txt read failed: " + e.getMessage());
        } finally {
            if (r != null) try { r.close(); } catch (IOException ignored) { }
        }
    }

    /** Adds everyone the server already has player data for (members from before this plugin). */
    private void seedFromServer() {
        StringBuilder fresh = new StringBuilder();
        for (OfflinePlayer p : Bukkit.getOfflinePlayers()) {
            if (p == null || p.getUniqueId() == null) continue;
            if (!p.hasPlayedBefore()) continue;
            if (members.add(p.getUniqueId())) fresh.append(p.getUniqueId()).append('\n');
        }
        if (fresh.length() > 0) append(fresh.toString());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        final UUID id = e.getPlayer().getUniqueId();
        // Set.add is true only the first time, so a rejoin is never counted again.
        if (members.add(id)) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, new Runnable() {
                @Override public void run() { append(id + "\n"); }
            });
        }
    }

    private void append(String text) {
        synchronized (fileLock) {
            BufferedWriter w = null;
            try {
                if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
                w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8));
                w.write(text);
            } catch (IOException ex) {
                plugin.getLogger().warning("members.txt write failed: " + ex.getMessage());
            } finally {
                if (w != null) try { w.close(); } catch (IOException ignored) { }
            }
        }
    }

    public boolean isReady() { return ready; }

    /** Unique members that ever joined this server (each counted once). */
    public int totalMembers() { return members.size(); }
}
