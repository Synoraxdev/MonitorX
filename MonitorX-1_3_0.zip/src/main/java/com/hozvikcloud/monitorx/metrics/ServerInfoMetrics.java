/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * All Rights Reserved - HozvikCloud Proprietary License (see LICENSE)
 */
package com.hozvikcloud.monitorx.metrics;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;

import java.util.List;

/** Basic server details shown in the "Server Info" part of the dashboard. */
public class ServerInfoMetrics {

    private final String motd;
    private final String minecraftVersion;
    private final String defaultGamemode;
    private final String difficulty;
    private final boolean onlineMode;
    private final boolean whitelist;
    private final int pluginCount;
    private final int worldCount;
    private final int viewDistance;
    private final boolean membersReady;
    private final int totalMembers;

    private ServerInfoMetrics(String motd, String minecraftVersion, String defaultGamemode, String difficulty,
                              boolean onlineMode, boolean whitelist, int pluginCount, int worldCount,
                              int viewDistance, boolean membersReady, int totalMembers) {
        this.motd = motd;
        this.minecraftVersion = minecraftVersion;
        this.defaultGamemode = defaultGamemode;
        this.difficulty = difficulty;
        this.onlineMode = onlineMode;
        this.whitelist = whitelist;
        this.pluginCount = pluginCount;
        this.worldCount = worldCount;
        this.viewDistance = viewDistance;
        this.membersReady = membersReady;
        this.totalMembers = totalMembers;
    }

    /** Must run on the main thread. */
    public static ServerInfoMetrics collect(PlayerStats stats) {
        String motd = "";
        try {
            String m = Bukkit.getMotd();
            if (m != null) motd = ChatColor.stripColor(m);
        } catch (Throwable ignored) { }

        String mc = "";
        try {
            String bv = Bukkit.getBukkitVersion();
            int dash = bv.indexOf('-');
            mc = dash > 0 ? bv.substring(0, dash) : bv;
        } catch (Throwable ignored) { }

        String gm = "";
        try { gm = String.valueOf(Bukkit.getDefaultGameMode()); } catch (Throwable ignored) { }

        String diff = "";
        try {
            List<World> worlds = Bukkit.getWorlds();
            if (!worlds.isEmpty()) diff = String.valueOf(worlds.get(0).getDifficulty());
        } catch (Throwable ignored) { }

        boolean online = true;
        try { online = Bukkit.getOnlineMode(); } catch (Throwable ignored) { }

        boolean wl = false;
        try { wl = Bukkit.hasWhitelist(); } catch (Throwable ignored) { }

        int plugins = 0;
        try { plugins = Bukkit.getPluginManager().getPlugins().length; } catch (Throwable ignored) { }

        int worlds = 0;
        try { worlds = Bukkit.getWorlds().size(); } catch (Throwable ignored) { }

        int view = -1;
        try { view = Bukkit.getViewDistance(); } catch (Throwable ignored) { }

        boolean ready = false;
        int total = 0;
        if (stats != null) {
            ready = stats.isReady();
            total = stats.totalMembers();
        }
        return new ServerInfoMetrics(motd, mc, gm, diff, online, wl, plugins, worlds, view, ready, total);
    }

    public String getMotd() { return motd; }
    public String getMinecraftVersion() { return minecraftVersion; }
    public String getDefaultGamemode() { return defaultGamemode; }
    public String getDifficulty() { return difficulty; }
    public boolean isOnlineMode() { return onlineMode; }
    public boolean isWhitelist() { return whitelist; }
    public int getPluginCount() { return pluginCount; }
    public int getWorldCount() { return worldCount; }
    public int getViewDistance() { return viewDistance; }
    public boolean isMembersReady() { return membersReady; }
    public int getTotalMembers() { return totalMembers; }
}
