# MonitorX

**Real-time Minecraft server monitor with a live Discord dashboard.**

MonitorX keeps **one single Discord message** and edits it in place every few seconds with your server's live stats: TPS, MSPT, RAM, CPU, disk, players, chunks and entities. No bot, no token, no channel spam. Just a webhook URL.

Made by **HozvikCloud** · Developer: **˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)**

---

## Features

- One live Discord message, edited in place (never spams new messages)
- Only a **Discord webhook URL** is needed (no bot token, no IDs)
- Live **TPS** and **MSPT** (real tick time on Paper; clearly marked estimate on Spigot)
- **RAM**, **JVM heap**, **CPU**, **disk** usage with progress bars
- Online players count, loaded chunks and entities (total and per world)
- Server **uptime** and ONLINE / OFFLINE status (the embed turns red when the server stops)
- Every section can be switched on or off, custom embed colour and optional emojis
- Works on **Java 8 and newer**, no extra libraries needed

## Compatibility

| | |
|---|---|
| Server software | Spigot, Paper, Purpur and other Bukkit-based servers |
| Minecraft versions | 1.8 and newer (designed for 1.8 up to the latest release) |
| Java | 8 or newer |
| Not supported | Folia, Fabric, Forge, NeoForge, BungeeCord, Velocity, Bedrock |

> Servers on Java 8 should use a recent Java 8 update (8u261 or newer) so that Discord's HTTPS certificate is trusted.

## Installation

1. Download `MonitorX-<version>.jar` and put it in your server's `plugins/` folder.
2. Start the server once. `plugins/MonitorX/config.yml` is created.
3. In Discord: **Channel settings → Integrations → Webhooks → New Webhook → Copy Webhook URL**.
4. Paste the URL into `config.yml` under `discord.webhook-url`.
5. Run `/monitorx reload` (or restart). The dashboard message appears in your channel.

## Configuration

`plugins/MonitorX/config.yml`

| Key | Default | Description |
|---|---|---|
| `discord.webhook-url` | *(empty)* | Your Discord webhook URL |
| `discord.message-id` | *(auto)* | Filled in automatically after the first post. Clear it with `/monitorx reset` |
| `monitor.refresh-interval-seconds` | `5` | How often the message is edited (minimum 1) |
| `monitor.embed-color` | `#2B2D31` | Embed sidebar colour (hex) |
| `monitor.progress-bar-length` | `12` | Length of the bars (5 to 20) |
| `monitor.show-resources` | `true` | RAM / CPU / Storage / JVM Heap |
| `monitor.show-configuration` | `true` | Software / Bukkit / TPS / MSPT |
| `monitor.show-live-stats` | `true` | CPU / Memory / Disk bars |
| `monitor.show-actions` | `true` | Players online |
| `monitor.show-world-details` | `true` | Chunks and entities |
| `monitor.emojis` | `{}` | Optional emoji overrides (unicode or Discord custom emoji) |

Discord allows about 5 edits per 5 seconds per webhook, so the default of 5 seconds is safe. If you see rate-limit warnings in the console, raise the interval.

## Commands

Main command: `/monitorx` (aliases: `/mx`, `/xmon`)

| Command | Description |
|---|---|
| `/monitorx status` | Show TPS, MSPT, heap, disk, uptime and webhook state in-game |
| `/monitorx reload` | Reload `config.yml` |
| `/monitorx forceupdate` | Push an update to Discord right now |
| `/monitorx reset` | Clear the saved message id and post a fresh message |
| `/monitorx help` | Show the command list |

## Permissions

| Permission | Default | Description |
|---|---|---|
| `monitorx.admin` | op | Use all `/monitorx` commands |

## About TPS and MSPT

- **Paper / Purpur:** MSPT is the real tick processing time reported by the server.
- **Spigot:** the server does not expose tick processing time, so MonitorX shows an estimate. A healthy server shows `<50 ms (est.)`; an overloaded one shows a `~value (est.)`.
- **Uptime** is the uptime of the server process, so it is not reset by `/monitorx reload`.

## Troubleshooting

| Problem | Fix |
|---|---|
| `Webhook not configured` | Set `discord.webhook-url` in `config.yml`, then `/monitorx reload` |
| `Webhook message ... not found` | The message was deleted. Run `/monitorx reset` |
| `Webhook rejected (401/403)` | The webhook was deleted or the URL is wrong. Create a new one |
| `Rate limited` | Increase `monitor.refresh-interval-seconds` |
| Nothing is posted on Java 8 | Update Java 8 to a recent build (8u261+) |

## Building from source

Requirements: JDK 8 or newer and Maven.

```bash
mvn clean package
```

The plugin jar is created at `target/MonitorX-<version>.jar`.

## License

Released under the [MIT License](LICENSE).

Copyright (c) 2026 HozvikCloud · ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
