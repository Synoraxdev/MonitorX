/**
 * Copyright (c) 2026 HozvikCloud
 * Code by ˚.🍫  ᵎᵎ Im2Jenil ࿐ (@im2jenil)
 * MIT License
 */
package com.hozvikcloud.monitorx.discord;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

// POST once to grab a message id, then PATCH it every refresh. Failures are
// logged and the same id is retried next cycle - we never auto-repost.
// HTTP is done by SimpleHttps so this works on Java 8 and every newer Java.
public class DiscordClient {

    private static final String BASE = "https://discord.com/api/webhooks";
    private static final int CONNECT_TIMEOUT_MS = 6000;
    private static final int READ_TIMEOUT_MS = 8000;

    private final Logger log;
    private final String ua;
    private final ExecutorService io;

    public DiscordClient(Logger log, String pluginVersion) {
        this.log = log;
        this.ua = "MonitorX/" + pluginVersion + " (Minecraft)";
        this.io = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "MonitorX-Discord-IO");
            t.setDaemon(true);
            return t;
        });
    }

    /** Stops the I/O thread. Call after the last request (plugin disable). */
    public void close() {
        io.shutdown();
    }

    private Map<String, String> headers() {
        Map<String, String> h = new HashMap<>();
        h.put("Content-Type", "application/json");
        h.put("User-Agent", ua);
        return h;
    }

    public CompletableFuture<String> postWebhookMessage(String id, String token, String json) {
        if (id == null || token == null) return CompletableFuture.completedFuture(null);
        String url = BASE + "/" + id + "/" + token + "?wait=true";
        return CompletableFuture.supplyAsync(() -> {
            try {
                SimpleHttps.Response resp = SimpleHttps.request("POST", url, headers(), json,
                        CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
                if (resp.status / 100 == 2) {
                    String mid = JsonObjectBuilder.extractStringField(resp.body, "id");
                    log.info("Webhook message posted (id=" + mid + ")");
                    return mid;
                }
                log.warning("Webhook POST " + resp.status + ": " + trim(resp.body));
                return null;
            } catch (Throwable t) {
                log.log(Level.WARNING, "Webhook POST error", t);
                return null;
            }
        }, io);
    }

    public CompletableFuture<Boolean> editWebhookMessage(String id, String token, String msgId, String json) {
        if (id == null || token == null || msgId == null || msgId.isEmpty()) {
            return CompletableFuture.completedFuture(false);
        }
        String url = BASE + "/" + id + "/" + token + "/messages/" + msgId;
        return CompletableFuture.supplyAsync(() -> {
            try {
                SimpleHttps.Response resp = SimpleHttps.request("PATCH", url, headers(), json,
                        CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
                int s = resp.status;
                if (s / 100 == 2) return true;
                if (s == 404) {
                    log.warning("Webhook message " + msgId + " not found. Run `/monitorx reset`.");
                    return false;
                }
                if (s == 401 || s == 403) {
                    log.warning("Webhook rejected (" + s + "). Update discord.webhook-url and reload.");
                    return false;
                }
                if (s == 429) {
                    log.warning("Rate limited. Bump monitor.refresh-interval-seconds in config.yml.");
                    return true;
                }
                log.warning("Webhook edit " + s + ": " + trim(resp.body));
                return false;
            } catch (Throwable t) {
                log.warning("Webhook edit error: " + t.getMessage());
                return false;
            }
        }, io);
    }

    private static String trim(String s) {
        if (s == null) return "";
        return s.length() > 200 ? s.substring(0, 200) + "..." : s;
    }
}
